// main.js: Core functionality for API AccessPanel extension UI

const LOGGING_ENABLED = false;
const storageKey = "clientdata";
let accessTokenTimerInterval = null;
let refreshTokenTimerInterval = null;
let lastRequestDetails = null;
let HERMES_MYAPIS_MODE = false;


// ===== UTILITIES ===== //
// Logging Control
const DEBUG_MODE = {
    enabled: false,      // Master switch for logging
    logLevel: 'INFO'     // Default log level (ERROR, WARN, INFO, DEBUG)
};

// Logger Utility
// Usage: appLogger.info(); appLogger.error(); appLogger.warn(); appLogger.debug(); appLogger.timestamp;
const appLogger = {
    timestamp() {
        return new Date().toISOString().slice(0, 19).replace('T', ' ');
    },

    error(message) {
        if (DEBUG_MODE.enabled) {
            console.error(`[${this.timestamp()}][ERROR] ${message}`);
        }
        // Always log errors to storage regardless of debug mode
        this.appendToStorage('ERROR', message);
    },

    warn(message) {
        if (DEBUG_MODE.enabled && ['ERROR', 'WARN'].includes(DEBUG_MODE.logLevel)) {
            console.warn(`[${this.timestamp()}][WARN] ${message}`);
        }
        this.appendToStorage('WARN', message);
    },

    info(message) {
        if (DEBUG_MODE.enabled && ['ERROR', 'WARN', 'INFO'].includes(DEBUG_MODE.logLevel)) {
            console.info(`[${this.timestamp()}][INFO] ${message}`);
        }
        this.appendToStorage('INFO', message);
    },

    debug(message) {
        if (DEBUG_MODE.enabled && DEBUG_MODE.logLevel === 'DEBUG') {
            console.debug(`[${this.timestamp()}][DEBUG] ${message}`);
        }
        this.appendToStorage('DEBUG', message);
    },

    // store logs in chrome.storage for later retrieval
    async appendToStorage(level, message) {
        try {
            const logEntry = {
                timestamp: this.timestamp(),
                level,
                message
            };
            
            chrome.storage.local.get({ extension_logs: [] }, (result) => {
                const logs = result.extension_logs;
                logs.push(logEntry);
                // Keep only last 1000 logs
                if (logs.length > 1000) logs.shift();
                chrome.storage.local.set({ extension_logs: logs });
            });
        } catch (error) {
            console.error('Failed to store log:', error);
        }
    }
};

// Download Utility For Export Functions
function downloadFile(filename, content, mimeType) {
	const blob = new Blob([content], {
		type: mimeType
	});
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	document.body.appendChild(a);
	a.click();
	document.body.removeChild(a);
	URL.revokeObjectURL(url);
}

// Format Local Date As YYYY-MM-DD With Optional Day Offset.
function formatLocalYMD(daysOffset = 0, base = new Date()) {
  // Start from local midnight to avoid DST/clock noise
  const d = new Date(base.getFullYear(), base.getMonth(), base.getDate());
  d.setDate(d.getDate() + daysOffset);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}
// ===================== //


// ===== REVEAL / HIDE FIELD HELPERS ===== //
// Toggle Visibility And Swap Icon
function toggleFieldVisibility(inputId, iconId) {
  const input = document.getElementById(inputId);
  const icon  = document.getElementById(iconId);
  if (!input || !icon) return;

  const nowPassword = input.type !== "password";
  input.type = nowPassword ? "password" : "text";
  icon.src = nowPassword ? "icons/eyeopen.png" : "icons/eyeclosed.png";
  icon.alt = nowPassword ? "Show" : "Hide";
}

// Attach Click Listener Once For Given Toggle Icon → Input Pair
function wireRevealToggleOnce(inputId, iconId) {
  const icon = document.getElementById(iconId);
  if (!icon || icon.dataset.wired === "1") return;
  icon.addEventListener("click", () => toggleFieldVisibility(inputId, iconId));
  icon.dataset.wired = "1";
}

// Ensure A Given Input Starts Masked
function ensureMasked(inputId) {
  const el = document.getElementById(inputId);
  if (!el) return;
  if (el.type !== "password") el.type = "password";
}
// ======================================= //


// ===== MENU BAR | BAR FUNCTIONS ===== //
// Menu Initializer
function initMenus() {
  const bar = document.querySelector('.menu-bar');
  if (!bar) return;

  const dropdowns = Array.from(bar.querySelectorAll('.dropdown'));
  const buttons = dropdowns.map(dd => dd.querySelector('.menu-btn'));

  const closeAll = (except = null) => {
    dropdowns.forEach(d => {
      if (d !== except) {
        d.classList.remove('open');
        const b = d.querySelector('.menu-btn');
        if (b) b.setAttribute('aria-expanded', 'false');
      }
    });
  };

  // toggle each menu on button click; close the rest
  buttons.forEach((btn, i) => {
    if (!btn) return;
    const dd = dropdowns[i];
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const willOpen = !dd.classList.contains('open');
      closeAll();
      dd.classList.toggle('open', willOpen);
      btn.setAttribute('aria-expanded', String(willOpen));
    });
  });

  // close menu when pointer leaves the defined area
  dropdowns.forEach((dd) => {
    dd.addEventListener('mouseleave', () => {
      dd.classList.remove('open');
      const b = dd.querySelector('.menu-btn');
      if (b) b.setAttribute('aria-expanded', 'false');
    });
  });


  // click outside closes all
  document.addEventListener('click', () => closeAll());

  // esc closes all
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeAll();
  });
}

// Click To Open Menu Item
function initClickMenus() {
  const bar = document.querySelector('.menu-bar');
  if (!bar) return;

  // All dropdowns EXCEPT the theme picker (it has its own open state already)
  const dropdowns = Array.from(bar.querySelectorAll('.dropdown:not(.theme-picker)'));

  // Clicking a menu button toggles that one; closes others
  dropdowns.forEach(dd => {
    const btn = dd.querySelector('.menu-btn');
    if (!btn) return;
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const isOpen = dd.classList.contains('open');
      dropdowns.forEach(d => d.classList.remove('open'));
      if (!isOpen) dd.classList.add('open');
    });
  });

  // Click outside closes all
  document.addEventListener('click', () => {
    dropdowns.forEach(d => d.classList.remove('open'));
  });

  // ESC closes all
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') dropdowns.forEach(d => d.classList.remove('open'));
  });
}
// ==================================== //

// ===== MENU BAR | ADMIN FUNCTIONS ===== //
// Clear All Data Button
async function clearAllData() {
    if (!confirm("Are you sure you want to clear ALL stored client data?")) return;

    await new Promise((resolve) => {
        chrome.storage.local.remove(storageKey, () => {
            appLogger.info("All client data cleared.");
            resolve();
        });
    });

    // stop timers and reset ui
    const accessTokenTimerBox = document.getElementById("timer");
    const refreshTokenTimerBox = document.getElementById("refresh-timer");
    stopAccessTokenTimer(accessTokenTimerBox);
    stopRefreshTokenTimer(refreshTokenTimerBox);

    await populateClientID();
    await populateAccessToken();
	await populateClientSecret();
    await populateRefreshToken();
    await restoreTokenTimers();
}

// Clear Client Data Button
async function clearClientData() {
    const clienturl = await getClientUrl();
    if (!clienturl) {
        alert("No valid client environment detected.");
        return;
    }

    if (!confirm(`Are you sure you want to clear data for: ${clienturl}?`)) return;

    const data = await loadClientData();
    if (data[clienturl]) {
        delete data[clienturl];
        await saveClientData(data);
        appLogger.info(`Data cleared for ${clienturl}`);
        alert(`Client data cleared for: ${clienturl}`);

        // stop timers and reset ui
        const accessTokenTimerBox = document.getElementById("timer");
        const refreshTokenTimerBox = document.getElementById("refresh-timer");
        stopAccessTokenTimer(accessTokenTimerBox);
        stopRefreshTokenTimer(refreshTokenTimerBox);

        await populateClientID();
        await populateAccessToken();
		await populateClientSecret();
        await populateRefreshToken();
        await restoreTokenTimers();
    } else {
        alert("No data found for this client environment.");
    }
}

// View Client Data Button
async function viewClientData() {
    appLogger.info("View Client Data clicked.");

    // get the client url
    const clienturl = await getClientUrl();
    if (!clienturl) {
        alert("No valid client URL detected.");
        return;
    }

    // load data from local storage
    const data = await loadClientData();
    const clientData = data[clienturl];

    if (!clientData) {
        alert("No data exists for the current client.");
        return;
    }

    // format client data for display
    const formattedData = JSON.stringify(clientData, null, 2);

    // open a new popup window to display the client data
    const popupWindow = window.open(
        "",
        "_blank",
        "width=850,height=350,scrollbars=yes,resizable=yes"
    );
    if (popupWindow) {
        popupWindow.document.write(`
            <html>
                <head>
                    <title>Client Data</title>
                    <style>
                        body {
                            font-family: Arial, sans-serif;
                            margin: 10px;
                        }
                        pre {
                            white-space: pre-wrap;
                            word-wrap: break-word;
                            background-color: #f4f4f4;
                            padding: 10px;
                            border: 1px solid #ddd;
                            border-radius: 5px;
							font-size: 1.2em;
                        }
                    </style>
                </head>
                <body>
                    <h2>Client Data for ${clienturl}</h2>
                    <pre>${formattedData}</pre>
                    <button onclick="window.close()">Close</button>
                </body>
            </html>
        `);
    } else {
        alert("Unable to open the popup window. Please check your browser settings.");
    }
}

// Export CSV Button
async function exportCSV() {
    const data = await loadClientData();
    if (!Object.keys(data).length) {
        alert("No client data available to export.");
        return;
    }

    let csvContent = "Client URL,Client ID,Client Secret,Token URL,API URL,Effective Date,Expiration Date,Edit Date\n";

    for (const [url, details] of Object.entries(data)) {
        csvContent += `"${url}","${details.clientid || ""}","${details.clientsecret || ""}","${details.tokenurl || ""}","${details.apiurl || ""}","${details.effectivedatetime || ""}","${details.expirationdatetime || ""}","${details.editdatetime || ""}"\n`;
    }

    const fileName = `hermes-clientdata-${new Date().toISOString().slice(0, 10)}.csv`;
    downloadFile(fileName, csvContent, "text/csv");

    appLogger.info("Client data exported as CSV.");

    alert(` CSV exported successfully!\nCheck your downloads folder for:\n ${fileName}`);
}

// Export JSON Button
async function exportJSON() {
    const data = await loadClientData();
    if (!Object.keys(data).length) {
        alert("No client data available to export.");
        return;
    }

    const sanitizedData = JSON.parse(JSON.stringify(data, (key, value) => {
        return (key === "accesstoken" || key === "refreshtoken") ? undefined : value;
    }));

    const fileName = `hermes-clientdata-${new Date().toISOString().slice(0, 10)}.json`;
    downloadFile(fileName, JSON.stringify(sanitizedData, null, 2), "application/json");

    appLogger.info("Client data exported as JSON.");

    alert(`JSON exported successfully!\nCheck your downloads folder for:\n${fileName}`);
}

// Import Data Button
async function importData() {
	const input = document.createElement("input");
	input.type = "file";
	input.accept = ".csv,.json";
	input.addEventListener("change", async (event) => {
		const file = event.target.files[0];
		if (!file) return;

		const reader = new FileReader();
		reader.onload = async (e) => {
			const content = e.target.result;
			const data = await loadClientData();

			try {
				if (file.name.endsWith(".json")) {
					const importedData = JSON.parse(content);
					for (const [url, details] of Object.entries(importedData)) {
						data[url] = {
							clientid: details.clientid || "",
							clientsecret: details.clientsecret || "",
							tokenurl: details.tokenurl || "",
							apiurl: details.apiurl || "",
							accesstoken: null, // clear sensitive fields
							refreshtoken: null, // clear sensitive fields
							editdatetime: new Date().toISOString()
						};
					}
				} else if (file.name.endsWith(".csv")) {
					const rows = content.split("\n").slice(1); // skip header
					for (const row of rows) {
						const [url, clientid, clientsecret, tokenurl, apiurl] = row.split(",").map((field) => field.replace(/"/g, "").trim());
						if (url) {
							data[url] = {
								clientid: clientid || "",
								clientsecret: clientsecret || "",
								tokenurl: tokenurl || "",
								apiurl: apiurl || "",
								accesstoken: null, // clear sensitive fields
								refreshtoken: null, // clear sensitive fields
								editdatetime: new Date().toISOString()
							};
						}
					}
				} else {
					throw new Error("Unsupported file format.");
				}

				await saveClientData(data);
				alert("Data imported successfully.");
				appLogger.info("Client data imported.");


				// refresh the ui
				await populateClientID();
				await populateAccessToken();
				await populateClientSecret();
				await populateRefreshToken();
				await restoreTokenTimers();
			} catch (error) {
				appLogger.error("Import failed:", error);
				alert("Failed to import data. Ensure the file is in the correct format.");
			}
		};
		reader.readAsText(file);
	});

	input.click();
}
// ====================================== //


// ===== MENU BAR | LINKS FUNCTIONS ===== //
// Boomi Button
async function linksBoomi() {
  if (!(await isValidSession())) {
    alert("Requires a valid ADP WorkForce Manager session.");
    return;
  }

  const clienturl = await getClientUrl();
  if (!clienturl) {
    appLogger.info("Client URL not found.");
    return;
  }

  const ssoClientUrl = createSsoUrl(clienturl);
  const boomiURL = `${ssoClientUrl}ihub#/integrationTemplatesDesigner?ctxt=designIntegrationTemplates&pageId=58`;
  appLogger.info("Opening Boomi URL:", boomiURL);

  // detect if in incognito mode
  chrome.windows.getCurrent({ populate: false }, (window) => {
    if (chrome.runtime.lastError) {
      appLogger.error(
        "Error detecting incognito mode:",
        chrome.runtime.lastError,
      );
      openURLNormally(boomiURL); // fallback
      return;
    }

    if (window.incognito) {
      appLogger.info("Opening in the same incognito session...");
      chrome.tabs.create({ url: boomiURL, active: true });
    } else {
      appLogger.info("Opening in a normal window...");
      openURLNormally(boomiURL);
    }
  });
}

// Install Integrations Button
async function linksInstallIntegrations() {
  if (!(await isValidSession())) {
    alert("Requires a valid ADP Workforce Manager session.");
    return;
  }

  const clienturl = await getClientUrl();
  if (!clienturl) {
    appLogger.info("Client URL not found.");
    return;
  }

  const ssoClientUrl = createSsoUrl(clienturl);
  const installIntegrationsURL = `${ssoClientUrl}metaui#/list/integration/?ctxt=configureIntegrations&pageId=57`;

  // detect if in incognito mode
  chrome.windows.getCurrent({ populate: false }, (window) => {
    if (chrome.runtime.lastError) {
      appLogger.error(
        "Error detecting incognito mode:",
        chrome.runtime.lastError,
      );
      openURLNormally(installIntegrationsURL); // fallback
      return;
    }

    if (window.incognito) {
      appLogger.info("Opening in the same incognito session...");
      chrome.tabs.create({ url: installIntegrationsURL, active: true });
    } else {
      appLogger.info("Opening in a normal window...");
      openURLNormally(installIntegrationsURL);
    }
  });
}

// Developer Portal
async function linksDeveloperPortal() {
  try {
    const hermesData = await fetch("apiaccesspanel.json").then((res) => res.json());
    const developerPortalURL = hermesData.details.urls.developerPortal;

    if (!developerPortalURL) {
      appLogger.error("Developer Portal URL not found in apiaccesspanel.json.");
      return;
    }

    // store a reference to the global window object
    const globalWindow = window;

    // detect if in incognito mode
    chrome.windows.getCurrent({ populate: false }, (win) => {
      if (win.incognito) {
        appLogger.info("Opening in the same incognito session...");
        chrome.tabs.create({ url: developerPortalURL, active: true });
      } else {
        appLogger.info("Opening in a normal window...");
        globalWindow.open(developerPortalURL, "_blank");
      }
    });
  } catch (error) {
    appLogger.error("Failed to load Developer Portal URL:", error);
  }
}
// ====================================== //


// ===== MENU BAR | THEMES FUNCTIONS ===== //
// Load Themes From themes.json
async function loadThemes() {
  try {
    const response = await fetch("themes/themes.json");
    if (!response.ok)
      throw new Error(
        `Failed to fetch themes. HTTP status: ${response.status}`,
      );
    const themesData = await response.json();
    appLogger.info("Themes loaded:", themesData);
    return themesData.themes;
  } catch (error) {
    appLogger.error("Error loading themes:", error);
    return {};
  }
}

// Populate Themes Dropdown
async function populateThemeDropdown() {
  const themes = await loadThemes();
  const dropdown = document.getElementById("theme-selector");
  if (!dropdown) {
    appLogger.error("Theme dropdown element not found in DOM.");
    return;
  }

  for (const themeKey in themes) {
    const theme = themes[themeKey];
    const option = document.createElement("option");
    option.value = themeKey;
    option.textContent = theme.name;
    dropdown.appendChild(option);
  }
}

// Apply the Selected Theme
async function applyTheme(themeKey) {
  const themes = await loadThemes();
  const selectedTheme = themes[themeKey];

  if (!selectedTheme) {
    appLogger.warn(`Theme "${themeKey}" not found.`);
    return;
  }

  const root = document.documentElement;
  const colors = selectedTheme.colors;

  // update color variables
  for (const [key, value] of Object.entries(colors)) {
    root.style.setProperty(`--${key}`, value);
  }

  // update font variables
  const fonts = selectedTheme.fonts;
  root.style.setProperty("--font-family", fonts["font-family-primary"]);
  root.style.setProperty("--title-font", fonts["title-font-primary"]);

  // save the selected theme in local storage
  chrome.storage.local.set({ selectedTheme: themeKey });
  appLogger.info(`Theme "${themeKey}" applied.`);
}

// Theme Selection
function themeSelection(event) {
  const selectedTheme = event.target.value;
  applyTheme(selectedTheme);
}

// Restore the Last Selected Theme On Load
async function restoreSelectedTheme() {
  chrome.storage.local.get("selectedTheme", async (result) => {
    const themeKey = result.selectedTheme || "WorkForce MGR"; // default theme
    await applyTheme(themeKey);

    const dropdown = document.getElementById("theme-selector");
    if (dropdown) dropdown.value = themeKey;
  });
}

// Build Themes Menu From Select
function buildThemeMenuFromSelect() {
  const select = document.getElementById('theme-selector');
  const menu = document.getElementById('theme-menu');
  if (!select || !menu) return;

  menu.innerHTML = '';
  [...select.options].forEach(opt => {
    if (!opt.value) return;
    const btn = document.createElement('button');
    btn.className = 'theme-item';
    btn.type = 'button';
    btn.dataset.theme = opt.value;
    btn.textContent = opt.textContent;
    menu.appendChild(btn);
  });
}

// Delegate Clicks In The Themes Menu
function wireThemeMenuClicks() {
  const menu = document.getElementById('theme-menu');
  if (!menu) return;

  menu.addEventListener('click', (e) => {
    const item = e.target.closest('.theme-item');
    if (!item) return;

    // Update the hidden select (keeps your existing handlers/persistence)
    const select = document.getElementById('theme-selector');
    if (select) {
      select.value = item.dataset.theme;
      // Fire the same logic your native select uses
      select.dispatchEvent(new Event('change', { bubbles: true }));
    }

    // Close the dropdown using the unified controller
    const dd = document.getElementById('themes-dropdown');
    const btn = document.getElementById('theme-menu-btn');
    if (dd) dd.classList.remove('open');
    if (btn) btn.setAttribute('aria-expanded', 'false');
  });
}
// ======================================= //


// ===== MENU BAR | HELP FUNCTIONS ===== //
// About Button
async function helpAbout() {
  try {
    const hermesData = await fetch("apiaccesspanel.json").then((res) => res.json());
    const aboutMessage = `
            Name: ${hermesData.name}
            Description: ${hermesData.details.description}
            Version: ${hermesData.details.version}
            Release Date: ${hermesData.details.release_date}
            Author: ${hermesData.details.author}`;

    // clean up the message to remove tabs
    const cleansedAboutMessage = aboutMessage.replace(/\t/g, "");
    alert(cleansedAboutMessage);
  } catch (error) {
    appLogger.error("Failed to load About information:", error);
  }
}

// Support
async function helpSupport() {
    try {
        const hermesData = await fetch("apiaccesspanel.json").then((res) => res.json());
        const contactEmail = hermesData.details.contact;

        const userConfirmed = confirm("Would you like to open a support ticket?");
        if (!userConfirmed) return;

        const mailtoLink = `mailto:${contactEmail}?subject=Hermes: Support Ticket Request&body=Please describe the support request here.`;
        window.location.href = mailtoLink;
		appLogger.info("Support mail opened");
    } catch (error) {
        appLogger.error("Failed to load support contact information:", error);
    }
}
// ===================================== //


// ===== LOCAL STORAGE FUNCTIONS ===== //
// Load Client Data From Local Storage
async function loadClientData() {
	return new Promise((resolve) => {
		chrome.storage.local.get([storageKey], (result) => {
			resolve(result[storageKey] || {});
		});
	});
}

// Save Client Data To Local Storage
async function saveClientData(data) {
	return new Promise((resolve) => {
		chrome.storage.local.set({
			[storageKey]: data
		}, () => resolve());
	});
}
// =================================== //


// ===== MAIN UI HELPERS ===== //
// Button Success Text Temporary
function setButtonTempText(btn, okText, ms = 2000, originalText = btn.textContent) {
  if (!btn) return;

  const isIcony = btn.classList.contains('icon-btn') || btn.querySelector('img');

  if (isIcony) {
    
    const origTitle = btn.getAttribute('title') || '';
    btn.setAttribute('title', okText);
    btn.classList.add('flash-ok');
    btn.disabled = true;

    setTimeout(() => {
      btn.classList.remove('flash-ok');
      btn.setAttribute('title', origTitle);
      btn.disabled = false;
    }, ms);
  } else {
    
    btn.textContent = okText;
    btn.disabled = true;
    setTimeout(() => {
      btn.textContent = originalText;
      btn.disabled = false;
    }, ms);
  }
}

// Button Fail Text Temporary
function setButtonFailText(btn, failText, ms = 2000, originalText = btn.textContent) {
  if (!btn) return;

  const isIcony = btn.classList.contains('icon-btn') || btn.querySelector('img');

  if (isIcony) {
    const origTitle = btn.getAttribute('title') || '';
    btn.setAttribute('title', failText);
    btn.classList.add('flash-fail');
    
    setTimeout(() => {
      btn.classList.remove('flash-fail');
      btn.setAttribute('title', origTitle);
    }, ms);
  } else {
    btn.textContent = failText;
    btn.disabled = false;
    setTimeout(() => {
      btn.textContent = originalText;
    }, ms);
  }
}

// Button Hourglass Animation
function startLoadingAnimation(button) {
    const hourglassFrames = ["⏳", "⌛"];
    let frameIndex = 0;
    let rotationAngle = 0;

    // store original text for later restoration
    const originalText = button.textContent;

    button.innerHTML = `Waiting... <span class="hourglass">${hourglassFrames[frameIndex]}</span>`;
    button.disabled = true;
    
    const hourglassSpan = button.querySelector(".hourglass");
    hourglassSpan.style.display = "inline-block";

    return {
        interval: setInterval(() => {
            frameIndex = (frameIndex + 1) % hourglassFrames.length;
            rotationAngle += 30;
            hourglassSpan.textContent = hourglassFrames[frameIndex];
            hourglassSpan.style.transform = `rotate(${rotationAngle}deg)`;
        }, 100),
        originalText // return this to be used later
    };
}

// Restore Token Timers
async function restoreTokenTimers() {
    appLogger.info("Restoring token timers...");

    const clienturl = await getClientUrl();
    if (!clienturl) {
        appLogger.info("No valid client environment detected. Resetting all timers.");
        const accessTokenTimerBox = document.getElementById("timer");
        const refreshTokenTimerBox = document.getElementById("refresh-timer");

        // reset timers in the UI
        stopAccessTokenTimer(accessTokenTimerBox);
        stopRefreshTokenTimer(refreshTokenTimerBox);
        return;
    }

    const data = await loadClientData();
    const clientData = data[clienturl] || {};
    const currentDateTime = new Date();

    // restore access token timer
    const accessTokenTimerBox = document.getElementById("timer");
    if (clientData.accesstoken) {
        const expirationTime = new Date(clientData.expirationdatetime);
        if (currentDateTime < expirationTime) {
            const remainingSeconds = Math.floor((expirationTime - currentDateTime) / 1000);
            startAccessTokenTimer(remainingSeconds, accessTokenTimerBox);
        } else {
            appLogger.info("Access token expired; resetting timer.");
            accessTokenTimerBox.textContent = "--:--";
        }
    } else {
        accessTokenTimerBox.textContent = "--:--";
    }

    // restore refresh token timer
    const refreshTokenTimerBox = document.getElementById("refresh-timer");
    if (clientData.refreshtoken) {
        const refreshExpirationTime = new Date(clientData.refreshExpirationDateTime);
        if (currentDateTime < refreshExpirationTime) {
            const remainingSeconds = Math.floor((refreshExpirationTime - currentDateTime) / 1000);
            startRefreshTokenTimer(remainingSeconds, refreshTokenTimerBox);
        } else {
            appLogger.info("Refresh token expired; resetting timer.");
            refreshTokenTimerBox.textContent = "--:--";
        }
    } else {
        refreshTokenTimerBox.textContent = "--:--";
    }
}
// =========================== //


// ===== TITLE BAR ACTIONS ===== //
// Reload app
function reloadApp() {
  window.location.reload();
}

// Reload App Initializer
function initTitleBarActions() {
  const reloadBtn = document.getElementById('reload-app');
  if (reloadBtn) {
    reloadBtn.addEventListener('click', reloadApp);
  }
}
// ============================= //


// ===== CLIENT URL/ID FIELDS AND BUTTONS ===== //
// Tenant Section Collapsed
function toggleTenantSection() {
  const toggleButton = document.getElementById("toggle-tenant-section");
  const content = document.getElementById("tenant-section-content");
  const wrapper = content?.parentElement;
  if (!toggleButton || !content || !wrapper) return;

  // toggle state
  const expanded = !content.classList.contains("expanded");
  content.classList.toggle("expanded", expanded);

  if (expanded) {
    wrapper.style.height = `${content.scrollHeight + toggleButton.offsetHeight}px`;
    toggleButton.textContent = "▲ Hide Tenant Information ▲";
  } else {
    wrapper.style.height = `${toggleButton.offsetHeight + 15}px`;
    toggleButton.textContent = "▼ Show Tenant Information ▼";
  }

  chrome.storage.local.set({ tenantSectionExpanded: expanded });
}

// Tenant Section Expanded
function restoreTenantSection() {
  chrome.storage.local.get("tenantSectionExpanded", (result) => {
    const isExpanded = !!result.tenantSectionExpanded;
    const toggleButton = document.getElementById("toggle-tenant-section");
    const content = document.getElementById("tenant-section-content");
    const wrapper = content?.parentElement;
    if (!toggleButton || !content || !wrapper) return;

    content.classList.toggle("expanded", isExpanded);
    if (isExpanded) {
      wrapper.style.height = `${content.scrollHeight + toggleButton.offsetHeight}px`;
      toggleButton.textContent = "▲ Hide Tenant Information ▲";
    } else {
      wrapper.style.height = `${toggleButton.offsetHeight + 15}px`;
      toggleButton.textContent = "▼ Show Tenant Information ▼";
    }
  });
}

// Populate the API Access Client URL Field
async function populateClientUrlField() {
  try {
    const input = document.getElementById("client-url");
    if (!input) return;

    const base = await getClientUrl();
    input.value = base ? toApiUrl(base) : "";
  } catch (e) {
    appLogger.error("populateClientUrlField failed:", e);
  }
}

// Refresh URL Button
async function refreshClientUrlClick() {
  const btn = document.getElementById("refresh-client-url");
  try {
    await populateClientUrlField();
    const val = (document.getElementById("client-url") || {}).value || "";
    if (val) {
      setButtonTempText(btn, "URL Refreshed");
    } else {
      setButtonFailText(btn, "No URL Detected");
    }
  } catch (e) {
    appLogger.error(e);
    setButtonFailText(btn, "Refresh Failed");
  }
}

// Copy URL Button
async function copyClientUrlClick() {
  const btn = document.getElementById("copy-client-url");
  try {
    const val = (document.getElementById("client-url") || {}).value || "";
    if (!val) {
      setButtonFailText(btn, "No URL to Copy");
      return;
    }

    // use clipboard api; fallback if needed
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(val);
    } else {
      // fallback approach
      const ta = document.createElement("textarea");
      ta.value = val;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
    }

    setButtonTempText(btn, "URL Copied");
  } catch (e) {
    appLogger.error("Copy failed:", e);
    setButtonFailText(btn, "Copy Failed");
  }
}

// Populate API Access Client ID Field
async function populateClientID() {
	const clienturl = await getClientUrl();
	const clientIDBox = document.getElementById("client-id");
	appLogger.info("Populating Client ID");

	if (!clienturl) {
		appLogger.info("Client URL not detected.");
		clientIDBox.value = "";
		clientIDBox.placeholder = "Requires WFMgr Login";
		clientIDBox.readOnly = true;
		return;
	}

	const data = await loadClientData();
	if (data[clienturl]?.clientid) {
		clientIDBox.value = data[clienturl].clientid;
		clientIDBox.placeholder = "";
	} else {
		clientIDBox.value = "";
		clientIDBox.placeholder = "Enter Client ID";
	}
}

// Save API Access Client ID Button
async function saveClientIDClick() {
    const button = document.getElementById("save-client-id");
    
    try {
        appLogger.info("Save Client ID button clicked.");

        if (!(await isValidSession())) {
            alert("Requires a valid ADP Workforce Manager session.");
            return;
        }

        const clienturl = await getClientUrl();
        if (!clienturl) {
            appLogger.info("No client URL detected.");
            return;
        }

        const clientid = document.getElementById("client-id").value.trim();
        if (!clientid) {
            alert("Client ID cannot be empty!");
            return;
        }

        const data = await loadClientData();
        data[clienturl] = {
            ...(data[clienturl] || {}),
            clientid: clientid,
            tokenurl: `${clienturl}accessToken?clientId=${clientid}`,
            apiurl: `${clienturl}api`,
            editdatetime: new Date().toISOString(),
        };

        await saveClientData(data);
        appLogger.info("Client ID saved:", clientid);

        // use helper function for success case
        setButtonTempText(button, "Client ID Saved!");
    } catch (error) {
        // use helper function for failure case
        appLogger.error("Failed to save Client ID:", error);
        setButtonFailText(button, "Save Failed!");
    }
}
// ============================================ //


// ===== ACCESS TOKEN UI FIELDS AND BUTTONS ===== //
// Access Token Section Collapsed
function toggleAccessSection() {
  const toggleButton = document.getElementById("toggle-access-section");
  const content = document.getElementById("access-section-content");
  const wrapper = content?.parentElement;
  if (!toggleButton || !content || !wrapper) return;

  const expanded = !content.classList.contains("expanded");
  content.classList.toggle("expanded", expanded);

  if (expanded) {
    wrapper.style.height = `${content.scrollHeight + toggleButton.offsetHeight}px`;
    toggleButton.textContent = "▲ Hide Access Token Options ▲";
  } else {
    wrapper.style.height = `${toggleButton.offsetHeight + 15}px`;
    toggleButton.textContent = "▼ Show Access Token Options ▼";
  }

  chrome.storage.local.set({ accessSectionExpanded: expanded });
}

// Access Token Section Expanded
function restoreAccessSection() {
  chrome.storage.local.get("accessSectionExpanded", (result) => {
    const isExpanded = !!result.accessSectionExpanded;
    const toggleButton = document.getElementById("toggle-access-section");
    const content = document.getElementById("access-section-content");
    const wrapper = content?.parentElement;
    if (!toggleButton || !content || !wrapper) return;

    content.classList.toggle("expanded", isExpanded);
    if (isExpanded) {
      wrapper.style.height = `${content.scrollHeight + toggleButton.offsetHeight}px`;
      toggleButton.textContent = "▲ Hide Access Token Options ▲";
    } else {
      wrapper.style.height = `${toggleButton.offsetHeight + 15}px`;
      toggleButton.textContent = "▼ Show Access Token Options ▼";
    }
  });
}

// Populate Access Token Field And Start Timer If Token Is Valid
async function populateAccessToken() {
	appLogger.info("Populating Access Token...");
	const clienturl = await getClientUrl();
	const accessTokenBox = document.getElementById("access-token");
	const timerBox = document.getElementById("timer");

	if (!clienturl) {
		appLogger.info("Client URL not found.");
		accessTokenBox.value = "Requires WFMgr Login";
		timerBox.textContent = "--:--";
		return;
	}

	const data = await loadClientData();
	const currentDateTime = new Date();

	if (data[clienturl]?.accesstoken) {
		const expirationTime = new Date(data[clienturl].expirationdatetime);

		if (currentDateTime > expirationTime) {
			appLogger.info("Access token has expired.");
			accessTokenBox.value = "Access Token Expired";
			timerBox.textContent = "--:--";
		} else {
			appLogger.info("Access token is valid.");
			accessTokenBox.value = data[clienturl].accesstoken;

			// calculate remaining time and start the timer
			const remainingSeconds = Math.floor((expirationTime - currentDateTime) / 1000);
			appLogger.info(`Timer will start with ${remainingSeconds} seconds remaining.`);
			startAccessTokenTimer(remainingSeconds, timerBox);
		}
	} else {
		appLogger.info("No access token found.");
		accessTokenBox.value = "Get Token";
		timerBox.textContent = "--:--";
	}
}

// Get Access Token Button
async function fetchToken() {
    appLogger.info("Fetching token...");
    const clienturl = await getClientUrl();
    if (!clienturl || !(await isValidSession())) {
        alert("Requires a valid ADP Workforce Manager session.");
        return;
    }

    const clientID = document.getElementById("client-id").value.trim();
    if (!clientID) {
        alert("Please enter a Client ID first.");
        return;
    }

    const tokenurl = `${clienturl}accessToken?clientId=${clientID}`;
    appLogger.info(`Requesting token from: ${tokenurl}`);

    // Check if the current window is incognito
    chrome.windows.getCurrent({ populate: false }, async (window) => {
        if (window.incognito) {
            appLogger.info("Running in incognito mode. Using tab-based token retrieval...");
            retrieveTokenViaNewTab(tokenurl);
        } else {
            appLogger.info("Running in normal mode. Using fetch...");
            fetchTokenDirectly(tokenurl, clienturl, clientID);
        }
    });
}

// Get Access Token Normal Mode (used by fetchToken())
async function fetchTokenDirectly(tokenurl, clienturl, clientID) {
    try {
        const response = await fetch(tokenurl, {
            method: "GET",
            credentials: "include",
            headers: {
                "Content-Type": "application/json",
                Accept: "application/json",
            },
        });

        if (!response.ok) {
            throw new Error(`Failed to fetch token. HTTP status: ${response.status}`);
        }

        const result = await response.json();
        appLogger.info("Token response:", result);

        processTokenResponse(result, clienturl, clientID, tokenurl);
    } catch (error) {
        appLogger.error("Error fetching token:", error.message);
        alert(`Failed to fetch token: ${error.message}`);
    }
}

// Get Access Token Incognito Mode (used by fetchToken())
async function retrieveTokenViaNewTab(tokenurl) {
    chrome.tabs.create({ url: tokenurl, active: false }, async (tab) => {
        setTimeout(() => {
            chrome.scripting.executeScript(
                {
                    target: { tabId: tab.id },
                    function: scrapeTokenFromPage,
                },
                async (injectionResults) => {
                    if (chrome.runtime.lastError) {
                        appLogger.info("Script injection failed:", chrome.runtime.lastError);
                    } else {
                        appLogger.info("Script executed, processing token...");

                        if (injectionResults && injectionResults[0].result) {
                            appLogger.info("Scraped token:", injectionResults[0].result);

                            // retrieve the existing client ID from storage
                            const baseClientUrl = new URL(tokenurl).origin + "/";
                            const storedData = await loadClientData();
                            const existingClientID = storedData[baseClientUrl]?.clientid || "unknown-client";

                            appLogger.info("Using clientid:", existingClientID);

                            // pass the correct client ID instead of "incognito-client"
                            processTokenResponse(
                                injectionResults[0].result,
                                baseClientUrl,
                                existingClientID,
                                tokenurl
                            );
                        } else {
                            appLogger.error("No token found on the page.");
                            alert("Failed to retrieve token from the page.");
                        }
                    }

                    // close the tab
                    chrome.tabs.remove(tab.id, () => {
                        if (chrome.runtime.lastError) {
                            console.log("Error closing tab:", chrome.runtime.lastError);
                        } else {
                            console.log("Tab closed successfully.");
                        }
                    });
                }
            );
        }, 1500); // wait for 1.5 seconds to let the page load
    });
}

// Scrape Token From Browser Tab (used by retrieveTokenViaNewTab())
function scrapeTokenFromPage() {
    try {
        const preElement = document.querySelector("pre"); // assuming the token is inside a <pre> tag
        if (!preElement) return null;

        const jsonText = preElement.innerText;
        return JSON.parse(jsonText);
    } catch (error) {
        appLogger.info("Error parsing token:", error);
        return null;
    }
}

// Process Token (used by fetchTokenDirectly() and retrieveTokenViaNewTab())
async function processTokenResponse(result, baseClientUrl, clientID, tokenurl) {
  const button = document.getElementById("get-token");

  try {
    const { accessToken, refreshToken, expiresInSeconds } = result;
    if (!accessToken || !refreshToken || !expiresInSeconds) {
      appLogger.info("Token response is missing required fields.");
      alert("Failed to fetch token: Invalid response.");
      setButtonFailText(button, "Token Failed!");
      return;
    }

    const now = new Date();
    const accessExp = new Date(now.getTime() + expiresInSeconds * 1000);
    const refreshExp = new Date(now.getTime() + 8 * 60 * 60 * 1000); // 8 hours

    // baseClientUrl is already normalized (e.g., https://foo-nossosomething/ )
    const data = await loadClientData();
    data[baseClientUrl] = {
      ...(data[baseClientUrl] || {}),
      clientid: clientID,
      tokenurl,     // <-- keep the full /accessToken?clientId=... here
      apiurl: data[baseClientUrl]?.apiurl || `${baseClientUrl}api`,
      accesstoken: accessToken,
      refreshtoken: refreshToken,
      effectivedatetime: now.toISOString(),
      expirationdatetime: accessExp.toISOString(),
      refreshExpirationDateTime: refreshExp.toISOString(),
      editdatetime: now.toISOString(),
    };

    appLogger.info("Updating local storage under key:", baseClientUrl, data[baseClientUrl]);
    await saveClientData(data);

    // ui updates
    populateAccessToken();
    populateRefreshToken();
    restoreTokenTimers();
    setButtonTempText(button, "Token Retrieved!");

  } catch (error) {
    appLogger.error("Failed to process token response:", error);
    setButtonFailText(button, "Token Failed!");
  }
}

// Start Timer for Access Token
function startAccessTokenTimer(seconds, timerBox) {
	if (accessTokenTimerInterval) {
		clearInterval(accessTokenTimerInterval);
		accessTokenTimerInterval = null;
	}

	let remainingTime = seconds;

	const updateTimer = () => {
		if (remainingTime <= 0) {
			clearInterval(accessTokenTimerInterval);
			accessTokenTimerInterval = null;
			timerBox.textContent = "--:--";
			appLogger.info("Access Token Timer expired.");

			// clear the remaining time in storage
			chrome.storage.local.remove("accessTokenTimer");
		} else {
			const minutes = Math.floor(remainingTime / 60);
			const seconds = remainingTime % 60;
			timerBox.textContent = `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
			remainingTime--;

			// save the remaining time to storage
			chrome.storage.local.set({
				accessTokenTimer: remainingTime
			});
		}
	};

	// update the timer immediately and then every second
	updateTimer();
	accessTokenTimerInterval = setInterval(updateTimer, 1000);
}

// Stop Access Token Timer
function stopAccessTokenTimer(timerBox) {
	if (accessTokenTimerInterval) {
		clearInterval(accessTokenTimerInterval);
		accessTokenTimerInterval = null;
		timerBox.textContent = "--:--"; // reset the timer box
		appLogger.info("Access Token Timer stopped");
	}

	// clear timer from storage
	//chrome.storage.local.remove("accessTokenTimer");
}

// Copy Access Token Button
function copyAccessToken() {
    const accessTokenBox = document.getElementById("access-token");
    const accessToken = accessTokenBox?.value;

    // validate access token before copying
    if (!accessToken || accessToken === "Get Token" || accessToken === "Access Token Expired") {
        appLogger.info("No valid Access Token available to copy.");
        return;
    }

    // copy token to clipboard
    navigator.clipboard.writeText(accessToken)
        .then(() => {
            // visual feedback: change button text
            const button = document.getElementById("copy-token");
            const originalText = button.textContent;

            button.textContent = "Copied!";
            button.disabled = true; // disable temporarily

            setTimeout(() => {
                button.textContent = originalText;
                button.disabled = false; // re-enable
            }, 2000);
        })
        .catch((error) => {
            appLogger.error("Failed to copy Access Token:", error);
        });
}
// ============================================== //


// ===== REFRESH TOKEN UI FIELDS AND BUTTONS ===== //
// Toggle Refresh Token Section Collapsed / Expanded
function toggleRefreshTokenOptions() {
    const toggleButton = document.getElementById("toggle-refresh-token-options");
    const content = document.getElementById("refresh-token-options-content");
    const wrapper = content.parentElement;

    // toggle expanded/collapsed state
    const isExpanded = content.classList.toggle("expanded");

    // dynamically calculate the height
    if (isExpanded) {
        wrapper.style.height = `${content.scrollHeight + toggleButton.offsetHeight}px`; // expand wrapper height
        toggleButton.textContent = "▲ Hide Refresh Token Options ▲";
    } else {
        wrapper.style.height = `${toggleButton.offsetHeight + 15}px`; // shrink wrapper height (15px padding)
        toggleButton.textContent = "▼ Show Refresh Token Options ▼";
    }

    // persist the state in local storage
    chrome.storage.local.set({ clientSecretRefreshExpanded: isExpanded });

}

// Restore Refresh Token Options Visibility On Load
function restoreRefreshTokenOptions() {
    chrome.storage.local.get("clientSecretRefreshExpanded", (result) => {
        const isExpanded = result.clientSecretRefreshExpanded || false;
        const toggleButton = document.getElementById("toggle-refresh-token-options");
        const content = document.getElementById("refresh-token-options-content");
        const wrapper = content.parentElement;

        // set initial state based on stored value
        if (isExpanded) {
            content.classList.add("expanded");
            wrapper.style.height = `${content.scrollHeight + toggleButton.offsetHeight}px`;
            toggleButton.textContent = "▲ Hide Refresh Token Options ▲";
        } else {
            content.classList.remove("expanded");
            wrapper.style.height = `${toggleButton.offsetHeight + 15}px`;
            toggleButton.textContent = "▼ Show Refresh Token Options ▼";
        }
    });
}

// Populate Client Secret Box
async function populateClientSecret() {
    const clienturl = await getClientUrl();
    const clientSecretBox = document.getElementById("client-secret");
	appLogger.info("Populating client secret.");

    if (!clienturl) {
        appLogger.info("Client URL not detected.");
        clientSecretBox.value = "";
        clientSecretBox.placeholder = "Requires WFMgr Login";
		clientSecretBox.readOnly = true;
        return;
    }

    const data = await loadClientData();
    if (data[clienturl]?.clientsecret) {
        clientSecretBox.value = data[clienturl].clientsecret;
        clientSecretBox.placeholder = "";
    } else {
        clientSecretBox.value = "";
        clientSecretBox.placeholder = "Enter Client Secret";
    }
}

// Toggle Client Secret Visibility
function toggleClientSecretVisibility() {
    const clientSecretBox = document.getElementById("client-secret");
    const toggleIcon = document.getElementById("toggle-client-secret");

    if (clientSecretBox.type === "password") {
        clientSecretBox.type = "text";
        toggleIcon.src = "icons/eyeclosed.png";
    } else {
        clientSecretBox.type = "password";
        toggleIcon.src = "icons/eyeopen.png";
    }
}

// Save Client Secret Button
async function saveClientSecretClick() {
    const button = document.getElementById("save-client-secret");
    
    try {
        appLogger.info("Save Client Secret button clicked.");

        if (!(await isValidSession())) {
            alert("Requires a valid ADP Workforce Manager session.");
            return;
        }

        const clienturl = await getClientUrl();
        if (!clienturl) {
            appLogger.info("No client URL detected.");
            return;
        }

        const clientsecret = document.getElementById("client-secret").value.trim();
        if (!clientsecret) {
            alert("Client Secret cannot be empty!");
            return;
        }

        const data = await loadClientData();
        data[clienturl] = {
            ...(data[clienturl] || {}),
            clientsecret: clientsecret,
            editdatetime: new Date().toISOString(),
        };

        await saveClientData(data);
        appLogger.info("Client Secret saved:", clientsecret);

        // use helper function for success case
        setButtonTempText(button, "Client Secret Saved!");
    } catch (error) {
        // use helper function for failure case
        appLogger.error("Failed to save Client Secret:", error);
        setButtonFailText(button, "Save Failed!");
    }
}

// Populate Refresh Token Box
async function populateRefreshToken() {
	appLogger.info("Populating Refresh Token...");
	const clienturl = await getClientUrl();
	const refreshTokenBox = document.getElementById("refresh-token");
	const refreshTimerBox = document.getElementById("refresh-timer");

	if (!clienturl) {
		appLogger.info("Client URL not found.");
		refreshTokenBox.value = "Requires WFMgr Login";
		refreshTimerBox.textContent = "--:--";
		return;
	}

	const data = await loadClientData();
	const currentDateTime = new Date();

	if (data[clienturl]?.refreshtoken) {
		const refreshExpirationTime = new Date(data[clienturl].refreshExpirationDateTime);

		if (currentDateTime > refreshExpirationTime) {
			appLogger.info("Refresh token has expired.");
			refreshTokenBox.value = "Refresh Token Expired";
			refreshTimerBox.textContent = "--:--";
		} else {
			appLogger.info("Refresh token is valid.");
			refreshTokenBox.value = data[clienturl].refreshtoken;

			// calculate remaining time and start the timer
			const remainingSeconds = Math.floor((refreshExpirationTime - currentDateTime) / 1000);
			appLogger.info(`Refresh Timer will start with ${remainingSeconds} seconds remaining.`);
			startRefreshTokenTimer(remainingSeconds, refreshTimerBox);
		}
	} else {
		appLogger.info("No refresh token found.");
		refreshTokenBox.value = "Refresh Token";
		refreshTimerBox.textContent = "--:--";
	}
}

// Refresh Access Token Using Refresh Token Button
async function refreshAccessToken() {
    const button = document.getElementById("refresh-access-token");
    
    try {
        appLogger.info("Refreshing Access Token...");
        const clienturl = await getClientUrl();
        if (!clienturl || !(await isValidSession())) {
            alert("Requires a valid ADP Workforce Manager session.");
            return;
        }

        const data = await loadClientData();
        const client = data[clienturl] || {};
        const { refreshtoken, clientid, clientsecret } = client;

        // validate refresh token
        if (!refreshtoken || refreshtoken === "Refresh Token" || new Date() > new Date(client.refreshExpirationDateTime)) {
            alert("No valid Refresh Token found. Please retrieve an Access Token first.");
            setButtonFailText(button, "No Valid Token!");
            return;
        }

        // validate client secret
        if (!clientsecret || clientsecret === "Enter Client Secret") {
            alert("Client Secret is required to refresh the Access Token.");
            setButtonFailText(button, "Missing Secret!");
            return;
        }

        const apiurl = `${clienturl}api/authentication/access_token`;
        appLogger.info(`Requesting new access token via refresh token at: ${apiurl}`);

        // make POST request
        const response = await fetch(apiurl, {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
            },
            body: new URLSearchParams({
                refresh_token: refreshtoken,
                client_id: clientid,
                client_secret: clientsecret,
                grant_type: "refresh_token",
                auth_chain: "OAuthLdapService",
            }),
        });

        if (!response.ok) {
            throw new Error(`Failed to refresh access token. HTTP status: ${response.status}`);
        }

        // parse response
        const result = await response.json();
        appLogger.info("Refresh Token response:", result);

        const { access_token, expires_in } = result;
        if (!access_token || !expires_in) {
            throw new Error("Response is missing required fields: 'access_token' or 'expires_in'.");
        }

        // calculate expiration time
        const currentDateTime = new Date();
        const accessTokenExpirationDateTime = new Date(currentDateTime.getTime() + expires_in * 1000);

        // update local storage
        data[clienturl] = {
            ...client,
            accesstoken: access_token,
            expirationdatetime: accessTokenExpirationDateTime.toISOString(),
            editdatetime: currentDateTime.toISOString(),
        };

        await saveClientData(data);

        // update the UI
        appLogger.info("Access Token refreshed and saved successfully.");
        populateAccessToken();
        restoreTokenTimers();

        // Use helper function for success case
        setButtonTempText(button, "Token Refreshed!");

    } catch (error) {
        appLogger.error("Error refreshing access token:", error.message);
        alert(`Failed to refresh access token: ${error.message}`);
        setButtonFailText(button, "Refresh Failed!");
    }
}

// Start Timer for Refresh Token
function startRefreshTokenTimer(seconds, timerBox) {
	if (refreshTokenTimerInterval) {
		clearInterval(refreshTokenTimerInterval);
		refreshTokenTimerInterval = null;
	}

	let remainingTime = seconds;

	const updateTimer = () => {
		if (remainingTime <= 0) {
			clearInterval(refreshTokenTimerInterval);
			refreshTokenTimerInterval = null;
			timerBox.textContent = "--:--";
			console.log("Refresh Token Timer expired.");
		} else {
			const minutes = Math.floor(remainingTime / 60);
			const seconds = remainingTime % 60;
			timerBox.textContent = `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
			remainingTime--;

			// save the remaining time to storage
			chrome.storage.local.set({
				refreshTokenTimer: remainingTime
			});
		}
	};

	updateTimer();
	refreshTokenTimerInterval = setInterval(updateTimer, 1000);
}

// Stop Refresh Token Timer
function stopRefreshTokenTimer(timerBox) {
	if (refreshTokenTimerInterval) {
		clearInterval(refreshTokenTimerInterval);
		refreshTokenTimerInterval = null;
		timerBox.textContent = "--:--";
		console.log("Refresh Token Timer stopped.");
	}
	
	// clear timer from storage
	//chrome.storage.local.remove("refreshTokenTimer");
}

// Copy Refresh Token Button
function copyRefreshToken() {
    const button = document.getElementById("copy-refresh-token");
    const refreshTokenBox = document.getElementById("refresh-token");
    const refreshToken = refreshTokenBox?.value;

    // validate refresh token before copying
    if (!refreshToken || refreshToken === "Refresh Token" || refreshToken === "Refresh Token Expired") {
        appLogger.info("No valid Refresh Token available to copy.");
        setButtonFailText(button, "No Token!");
        return;
    }

    // copy refresh token to clipboard
    navigator.clipboard.writeText(refreshToken)
        .then(() => {
            setButtonTempText(button, "Copied!");
        })
        .catch((error) => {
            appLogger.error("Failed to copy Refresh Token:", error);
            setButtonFailText(button, "Copy Failed!");
        });
}
// =============================================== //


// ===== API LIBRARY FUNCTIONS ===== //
const MYAPIS_KEY = "hermes_myapis"; // [{id,name,method,endpoint,body,createdAt,updatedAt}]

// Toggle API Library Visibility Section Collapsed / Expanded
function toggleApiLibrary() {
    const toggleButton = document.getElementById("toggle-api-library");
    const content = document.getElementById("api-library-content");
    const wrapper = content.parentElement;

    // toggle expanded/collapsed state
    const isExpanded = content.classList.toggle("expanded");

    // dynamically calculate the height
    if (isExpanded) {
        wrapper.style.height = `${content.scrollHeight + toggleButton.offsetHeight}px`;
        toggleButton.textContent = "▲ Hide API Library ▲";
    } else {
        wrapper.style.height = `${toggleButton.offsetHeight + 15}px`;
        toggleButton.textContent = "▼ Show API Library ▼";
    }

    // persist the state in local storage
    chrome.storage.local.set({ apiLibraryExpanded: isExpanded });

}

// Restore API Library Visibility on Load
function restoreApiLibrary() {
    chrome.storage.local.get("apiLibraryExpanded", (result) => {
        const isExpanded = result.apiLibraryExpanded || false;
        const toggleButton = document.getElementById("toggle-api-library");
        const content = document.getElementById("api-library-content");
        const wrapper = content.parentElement;

        // set initial state based on stored value
        if (isExpanded) {
            content.classList.add("expanded");
            wrapper.style.height = `${content.scrollHeight + toggleButton.offsetHeight}px`;
            toggleButton.textContent = "▲ Hide API Library ▲";
        } else {
            content.classList.remove("expanded");
            wrapper.style.height = `${toggleButton.offsetHeight + 15}px`;
            toggleButton.textContent = "▼ Show API Library ▼";
        }
    });
}

// Load Saved My API's
async function getSavedMyApis() {
  return new Promise((resolve) => {
    chrome.storage.local.get([MYAPIS_KEY], (res) => resolve(res[MYAPIS_KEY] || []));
  });
}

// Load A Saved My API Entry By Selector Value "myapi:<id>"
async function loadSavedEntryByKey(selectedKey) {
  if (!selectedKey || !selectedKey.startsWith("myapi:")) return null;
  const id = selectedKey.slice(6);
  const { hermes_myapis } = await new Promise((resolve) =>
    chrome.storage.local.get(["hermes_myapis"], resolve)
  );
  const list = hermes_myapis || [];
  return list.find((x) => x.id === id) || null;
}

// Save My API Entry To User Lcoal Storage
async function setSavedMyApis(list) {
  return new Promise((resolve) => chrome.storage.local.set({ [MYAPIS_KEY]: list }, resolve));
}

// Generate Unique Key For My API Entry
function genId() {
  return "a" + Math.random().toString(36).slice(2) + Date.now().toString(36);
}

// Clear DevLink
function clearDevLinkBanner() {
  const a = document.getElementById("api-devlink");
  if (!a) return;
  a.hidden = true;
  a.removeAttribute("href");
  a.textContent = "";
}

// Populate Public API Library
async function populateApiDropdownPublic() {
  const sel = document.getElementById("api-selector");
  if (!sel) return;
  HERMES_MYAPIS_MODE = false;
  sel.innerHTML = "";
  clearDevLinkBanner();

  // switch-to-my-api
  const toMy = document.createElement("option");
  toMy.value = "__VIEW_MY_APIS__";
  toMy.textContent = "View My APIs…";
  sel.appendChild(toMy);

  // placeholder for public api drop down
  sel.insertAdjacentHTML("beforeend", '<option value="" disabled selected>Select Public API...</option>');

  // load and list public library
  const resp = await fetch("apilibrary/apilibrary.json");
  if (!resp.ok) throw new Error(`Failed to fetch API library. HTTP ${resp.status}`);
  const data = await resp.json();
  const lib = data.apiLibrary || {};

  for (const key in lib) {
    if (key.startsWith("_")) continue;
    const opt = document.createElement("option");
    opt.value = key;
    opt.textContent = lib[key].name;
    sel.appendChild(opt);
  }
}

// Populate My API List Dropdown
async function populateApiDropdownMyApis() {
  const sel = document.getElementById("api-selector");
  if (!sel) return;
  HERMES_MYAPIS_MODE = true;
  sel.innerHTML = "";
  clearDevLinkBanner();

  // Switch-to-Public
  const toPub = document.createElement("option");
  toPub.value = "__VIEW_PUBLIC_APIS__";
  toPub.textContent = "View Public APIs…";
  sel.appendChild(toPub);

  // Manage My APIs
  const manage = document.createElement("option");
  manage.value = "__MANAGE_MY_APIS__";
  manage.textContent = "Manage My APIs…";
  sel.appendChild(manage);

  // Placeholder
  sel.insertAdjacentHTML("beforeend", '<option value="" disabled selected>Select My API…</option>');

  // ---- NEW: Ad-Hoc entries available directly in My APIs mode ----
  const adhocGet = document.createElement("option");
  adhocGet.value = "adHocGet";
  adhocGet.textContent = "Ad-Hoc GET";
  sel.appendChild(adhocGet);

  const adhocPost = document.createElement("option");
  adhocPost.value = "adHocPost";
  adhocPost.textContent = "Ad-Hoc POST";
  sel.appendChild(adhocPost);

  // (Optional) visual separator
  const sep = document.createElement("option");
  sep.value = "__SEP__";
  sep.textContent = "────────";
  sep.disabled = true;
  sel.appendChild(sep);

  // Load saved list
  const items = await getSavedMyApis();

  if (!items.length) {
    const empty = document.createElement("option");
    empty.value = "__EMPTY__";
    empty.textContent = "(No saved APIs yet)";
    empty.disabled = true;
    sel.appendChild(empty);
    return;
  }

  // Append saved entries
  items.forEach((item) => {
    const opt = document.createElement("option");
    opt.value = `myapi:${item.id}`;
    opt.textContent = `${item.name} (${item.method})`;
    opt.title = `${item.method} ${item.endpoint}`;
    sel.appendChild(opt);
  });
}

// Wrapper To Handle Public vs My API's
async function populateApiDropdown() {
  if (HERMES_MYAPIS_MODE) return populateApiDropdownMyApis();
  return populateApiDropdownPublic();
}

// Load API Public Library From apilibrary.json
async function loadApiLibrary() {
    try {
        const response = await fetch("apilibrary/apilibrary.json");
        if (!response.ok) throw new Error(`Failed to load API Library: ${response.status}`);
        const apiLibraryData = await response.json();
        appLogger.info("API Library loaded:", apiLibraryData);
        return apiLibraryData.apiLibrary;
    } catch (error) {
        appLogger.error("Error loading API Library:", error);
        return {};
    }
}

// Clear Existing Parameters Button
function clearParameters() {
  const queryContainer = document.getElementById("query-parameters-container");
  const bodyContainer = document.getElementById("body-parameters-container");
  const pathContainer = document.getElementById("path-parameters-container");

  if (queryContainer) {
    queryContainer.innerHTML = ""; // clear query parameters
  }
  if (bodyContainer) {
    bodyContainer.innerHTML = ""; // clear body parameters
  }
  if (pathContainer) {
    pathContainer.innerHTML = ""; // clear path parameters
  }

  appLogger.info("API Parameters cleared successfully.");
}

// Ensure A Host Node For The Dev Portal Link Exists Just Above The Query Container (DEPRECATED?)
/*function ensureDevLinkHost() {
  const section = document.getElementById("parameter-section");
  const queryContainer = document.getElementById("query-parameters-container");
  if (!section || !queryContainer) return null;

  let host = document.getElementById("devlink-container");
  if (!host) {
    host = document.createElement("div");
    host.id = "devlink-container";
    host.className = "devlink-container"; // distinct class for styling
    section.insertBefore(host, queryContainer); // place above Query Parameters
  }
  return host;
}*/

// Show / Clear The Dev Portal Link Banner For A Given API Object (public API's only)
function renderDevLinkBanner(selectedApiKey, apiObjOrNull) {
  const a = document.getElementById("api-devlink");
  if (!a) return;

  // hide for my apis & ad-hoc and for missing devlink data
  if (
    !apiObjOrNull ||
    selectedApiKey.startsWith("myapi:") ||
    selectedApiKey === "adHocGet" ||
    selectedApiKey === "adHocPost" ||
    !apiObjOrNull.devLink ||
    !apiObjOrNull.devLink.url ||
    !apiObjOrNull.devLink.urlText
  ) {
    a.hidden = true;
    a.removeAttribute("href");
    a.textContent = "";
    return;
  }

  // Show populated dev link
  a.href = apiObjOrNull.devLink.url;
  a.textContent = apiObjOrNull.devLink.urlText;
  a.hidden = false;
}

// Render Path Parameters
function renderPathParamRow(param) {
  const wrap = document.createElement("div");
  wrap.className = "query-param-wrapper";

  const label = document.createElement("label");
  label.textContent = `${param.name}:`;
  label.setAttribute("for", `path-${param.name}`);
  wrap.appendChild(label);

  const inputType = (param.type || "text").toLowerCase();

  const input = document.createElement("input");
  input.type = inputType === "integer" ? "number" : "text";
  input.id = `path-${param.name}`;
  input.className = "query-param-input";
  input.dataset.name = param.name;

  if (param.defaultValue !== undefined && param.defaultValue !== "") {
    input.value = String(param.defaultValue);
  } else {
    input.placeholder = param.description || "Enter value";
  }

  wrap.appendChild(input);
  return wrap;
}

// Populate the Path Parameters area (similar to query/body)
async function populatePathParameters(selectedApiKey) {
  const host = document.getElementById("path-parameters-container");
  if (!host) return;

  host.innerHTML = "";

  // ad-hoc modes don’t use path param ui
  if (selectedApiKey === "adHocGet" || selectedApiKey === "adHocPost" || selectedApiKey?.startsWith("myapi:")) {
    return;
  }

  const apiLibrary = await loadApiLibrary();
  const api = apiLibrary[selectedApiKey];
  if (!api) return;

  const list = api.pathParameters || [];
  if (!list.length) return;

  const header = document.createElement("div");
  header.className = "parameter-header";
  header.textContent = "Path Parameters";
  host.appendChild(header);

  if (api.pathParametersHelp) {
    const help = document.createElement("p");
    help.className = "parameter-help-text";
    help.textContent = api.pathParametersHelp;
    host.appendChild(help);
  }

  list.forEach(p => host.appendChild(renderPathParamRow(p)));
}

// Replace {name} tokens in a url template with values from the ui
function buildUrlWithPathParams(urlTemplate, apiDef) {
  let url = String(urlTemplate || "");
  const list = apiDef?.pathParameters || [];
  if (!list.length) return url;

  // collect values
  const values = {};
  list.forEach(p => {
    const el = document.getElementById(`path-${p.name}`);
    values[p.name] = (el?.value ?? "").trim();
  });

  // replace tokens {name}
  url = url.replace(/\{([^}]+)\}/g, (match, name) => {
    const v = values[name];
    // if missing → leave token for now; the guard below will catch it
    return (v !== undefined && v !== "") ? encodeURIComponent(v) : match;
  });

  // guard: if any placeholders remain, fail gracefully
  if (/\{[^}]+\}/.test(url)) {
    throw new Error("One or more path parameters are missing.");
  }

  return url;
}

// Populate Query Parameters
async function populateQueryParameters(selectedApiKey) {
  try {
    const apiLibrary = await loadApiLibrary(); // load the api library
    const selectedApi = apiLibrary[selectedApiKey] || null;

    // If you added the dev portal banner helper, keep this:
    renderDevLinkBanner?.(selectedApiKey, selectedApi);

    if (!selectedApi) {
      appLogger.info("Selected API not found in the library.");
      return;
    }

    const queryContainer = document.getElementById("query-parameters-container");
    queryContainer.innerHTML = ""; // clear existing parameters

    // Ad-hoc keys: single endpoint text box
    if (selectedApiKey === "adHocGet" || selectedApiKey === "adHocPost") {
      const queryHeader = document.createElement("div");
      queryHeader.className = "parameter-header";
      queryHeader.textContent = "Endpoint URL with Query Parameters";
      queryContainer.appendChild(queryHeader);

      const endpointInput = document.createElement("input");
      endpointInput.type = "text";
      endpointInput.id = "adhoc-endpoint";
      endpointInput.classList.add("query-param-input");
      endpointInput.placeholder = "/v1/endpoint?queryParam=value";
      queryContainer.appendChild(endpointInput);
      return;
    }

    const params = selectedApi.queryParameters || [];
    if (!params.length) {
      appLogger.info("No query parameters for this API.");
      return;
    }

    // Header
    const queryHeader = document.createElement("div");
    queryHeader.className = "parameter-header";
    queryHeader.textContent = "Query Parameters";
    queryContainer.appendChild(queryHeader);

    // Optional help text
    if (selectedApi.queryParametersHelp) {
      const queryHelpText = document.createElement("p");
      queryHelpText.className = "parameter-help-text";
      queryHelpText.textContent = selectedApi.queryParametersHelp;
      queryContainer.appendChild(queryHelpText);
    }

    params.forEach((param) => {
      const wrap = document.createElement("div");
      wrap.classList.add("query-param-wrapper");

      const label = document.createElement("label");
      label.textContent = `${param.name}:`;
      label.setAttribute("for", `query-${param.name}`);
      wrap.appendChild(label);

      const type = (param.type || "").toLowerCase();

      // --- SELECT (supports {label,value} or string options) ---
      if (type === "select") {
        const sel = document.createElement("select");
        sel.id = `query-${param.name}`;
        sel.classList.add("query-param-input");

        // placeholder
        const ph = document.createElement("option");
        ph.value = "";
        ph.textContent = param.description || /*"Select an option"*/ "";
        ph.disabled = true;
        ph.selected = true;
        ph.hidden = true;
        sel.appendChild(ph);

        // label/value options
        const opts = normalizeOptions(param.options);
        opts.forEach(({ label: lbl, value }) => {
          const o = document.createElement("option");
          o.value = String(value);   // API value
          o.textContent = lbl;       // UI label
          sel.appendChild(o);
        });

        // placeholder styling behavior
        sel.classList.add("placeholder");
        sel.addEventListener("change", () => {
          if (sel.value === "") sel.classList.add("placeholder");
          else sel.classList.remove("placeholder");
        });

        if (param.defaultValue !== undefined && param.defaultValue !== "") {
          sel.value = String(param.defaultValue);
          if (sel.value !== "") sel.classList.remove("placeholder");
        }

        wrap.appendChild(sel);
        queryContainer.appendChild(wrap);
        return;
      }

      // --- BOOLEAN (right-aligned select, values "true"/"false") ---
      if (type === "boolean") {
        const sel = document.createElement("select");
        sel.id = `query-${param.name}`;
        sel.classList.add("query-param-input");

        const ph = document.createElement("option");
        ph.value = "";
        ph.textContent = param.description || /*"Select an option"*/ "";
        ph.disabled = true;
        ph.selected = true;
        ph.hidden = true;
        sel.appendChild(ph);

        // Use provided options if present, else [true,false]
        const boolOpts = (param.options && param.options.length)
          ? param.options.map((v) => String(v).toLowerCase() === "true")
          : [true, false];

        boolOpts.forEach((val) => {
          const o = document.createElement("option");
          o.value = val ? "true" : "false";   // API value
          o.textContent = val ? "True" : "False";
          sel.appendChild(o);
        });

        sel.classList.add("placeholder");
        sel.addEventListener("change", () => {
          if (sel.value === "") sel.classList.add("placeholder");
          else sel.classList.remove("placeholder");
        });

        if (typeof param.defaultValue !== "undefined" && param.defaultValue !== "") {
          const dv = typeof param.defaultValue === "boolean"
            ? (param.defaultValue ? "true" : "false")
            : String(param.defaultValue).toLowerCase();
          if (dv === "true" || dv === "false") {
            sel.value = dv;
            sel.classList.remove("placeholder");
          }
        }

        wrap.appendChild(sel);
        queryContainer.appendChild(wrap);
        return;
      }

      // --- DATE (supports relative offsets like "-1") ---
      if (type === "date") {
        const input = document.createElement("input");
        input.type = "date";
        input.id = `query-${param.name}`;
        input.classList.add("query-param-input");

        if (typeof param.defaultValue === "string" && /^[+-]?\d+$/.test(param.defaultValue)) {
          const daysOffset = parseInt(param.defaultValue, 10);
          input.value = formatLocalYMD(daysOffset);   // local date (no UTC drift)
        } else if (param.defaultValue) {
          input.value = param.defaultValue;
        } else {
          // leave empty; placeholder text can come from CSS if desired
        }

        wrap.appendChild(input);
        queryContainer.appendChild(wrap);
        return;
      }

      // --- DEFAULT: plain text ---
      const input = document.createElement("input");
      input.type = "text";
      input.id = `query-${param.name}`;
      input.classList.add("query-param-input");

      if (param.defaultValue !== undefined && param.defaultValue !== "") {
        input.value = param.defaultValue;
      } else {
        input.placeholder = param.description || "Enter value";
      }

      wrap.appendChild(input);
      queryContainer.appendChild(wrap);
    });

    appLogger.info("Query parameters populated successfully.");
  } catch (error) {
    appLogger.error("Error populating query parameters:", error);
  }
}

// Populate Body Parameters
async function populateBodyParameters(selectedApiKey) {
  try {
    const apiLibrary = await loadApiLibrary();
    const selectedApi = apiLibrary[selectedApiKey];

    const bodyParamContainer = document.getElementById("body-parameters-container");
    if (!bodyParamContainer) {
      appLogger.info("Body Parameters container not found.");
      return;
    }

    bodyParamContainer.innerHTML = "";

    // Ad-hoc POST: full JSON textarea
    if (selectedApiKey === "adHocPost") {
      const bodyHeader = document.createElement("div");
      bodyHeader.className = "parameter-header";
      bodyHeader.textContent = "Full JSON Body";
      bodyParamContainer.appendChild(bodyHeader);

      const textarea = document.createElement("textarea");
      textarea.id = "adhoc-body";
      textarea.className = "json-textarea";
      textarea.placeholder = "Enter full JSON body here...";
      bodyParamContainer.appendChild(textarea);
      return;
    }

    if (selectedApi?.method === "GET") return;
    if (!selectedApi || !selectedApi.bodyParameters) return;

    // Header
    const bodyHeader = document.createElement("div");
    bodyHeader.className = "parameter-header";
    bodyHeader.textContent = "Body Parameters";
    bodyParamContainer.appendChild(bodyHeader);

    // Optional help text
    if (selectedApi.bodyParametersHelp) {
      const bodyHelpText = document.createElement("p");
      bodyHelpText.className = "parameter-help-text";
      bodyHelpText.textContent = selectedApi.bodyParametersHelp;
      bodyParamContainer.appendChild(bodyHelpText);
    }

    // Build each parameter row
    selectedApi.bodyParameters.forEach((param) => {
      const paramWrapper = document.createElement("div");
      paramWrapper.className = "body-param-wrapper";

      // Label
      let labelText = param.name;
      if (param.type === "multi-text" && param.validation?.maxEntered) {
        labelText += ` (max = ${param.validation.maxEntered})`;
      }
      const label = document.createElement("label");
      label.htmlFor = `body-param-${param.name}`;
      label.textContent = labelText;
      label.className = "body-param-label";
      paramWrapper.appendChild(label);

      // Branch per type
      if (param.type === "multi-select") {
        // CHECKBOX LIST (supports label/value via normalizeOptions)
        const multiSelectContainer = document.createElement("div");
        multiSelectContainer.className = "multi-select-container";

        const opts = normalizeOptions(param.options);
        opts.forEach(({ label, value }) => {
          const checkboxWrapper = document.createElement("div");
          checkboxWrapper.className = "checkbox-wrapper";

          const checkbox = document.createElement("input");
          checkbox.type = "checkbox";
          checkbox.value = String(value);  // API value
          checkbox.dataset.path = param.path;
          checkbox.dataset.type = param.type;
          checkbox.id = `body-param-${param.name}-${value}`;

          // defaultValue can be array or single
          const def = param.defaultValue;
          if (Array.isArray(def) && def.map(String).includes(String(value))) {
            checkbox.checked = true;
          } else if (typeof def !== "undefined" && String(def) === String(value)) {
            checkbox.checked = true;
          }

          const checkboxLabel = document.createElement("label");
          checkboxLabel.htmlFor = checkbox.id;
          checkboxLabel.textContent = label; // UI label

          checkboxWrapper.appendChild(checkbox);
          checkboxWrapper.appendChild(checkboxLabel);
          multiSelectContainer.appendChild(checkboxWrapper);
        });

        paramWrapper.appendChild(multiSelectContainer);

      } else if (param.type === "multi-text") {
        // STACKED MULTI-TEXT (unchanged)
        paramWrapper.style.display = "block";
        const multiTextContainer = document.createElement("div");
        multiTextContainer.className = "multi-text-container";

        const addButton = document.createElement("button");
        addButton.type = "button";
        addButton.className = "btn btn-add-item";
        addButton.textContent = "Add Entry";
        addButton.addEventListener("click", () => {
          const textInput = document.createElement("input");
          textInput.type = "text";
          textInput.className = "body-param-input";
          textInput.dataset.path = param.path;
          textInput.dataset.type = param.type;
          textInput.placeholder = param.description || "Enter value";
          multiTextContainer.appendChild(textInput);
        });
        multiTextContainer.appendChild(addButton);

        const defaultTextInput = document.createElement("input");
        defaultTextInput.type = "text";
        defaultTextInput.className = "body-param-input";
        defaultTextInput.dataset.path = param.path;
        defaultTextInput.dataset.type = param.type;
        defaultTextInput.placeholder = param.description || "Enter value";
        multiTextContainer.appendChild(defaultTextInput);

        paramWrapper.appendChild(multiTextContainer);

      } else if (param.type === "select") {
        // SINGLE SELECT with label/value support
        paramWrapper.classList.add("body-select-wrapper");

        const dropdown = document.createElement("select");
        dropdown.className = "body-param-input body-select-input";
        dropdown.dataset.path = param.path;
        dropdown.dataset.type = param.type;
        dropdown.id = `body-param-${param.name}`;

        // Placeholder
        const placeholderOption = document.createElement("option");
        placeholderOption.value = "";
        placeholderOption.textContent = param.description || /*"Select an option"*/ "";
        placeholderOption.disabled = true;
        placeholderOption.selected = true;
        placeholderOption.hidden = true;
        dropdown.appendChild(placeholderOption);

        // Options via normalizeOptions
        const opts = normalizeOptions(param.options);
        opts.forEach(({ label, value }) => {
          const optEl = document.createElement("option");
          optEl.value = String(value);    // API value
          optEl.textContent = label;      // UI label
          dropdown.appendChild(optEl);
        });

        // Default selection (value)
        if (typeof param.defaultValue !== "undefined" && param.defaultValue !== "") {
          dropdown.value = String(param.defaultValue);
        }

        paramWrapper.appendChild(dropdown);

      } else if (param.type === "boolean") {
        // BOOLEAN SELECT (true/false options, aligned right)
        paramWrapper.classList.add("body-boolean-wrapper");

        const dropdown = document.createElement("select");
        dropdown.className = "body-param-input body-boolean-input";
        dropdown.dataset.path = param.path;
        dropdown.dataset.type = param.type;
        dropdown.id = `body-param-${param.name}`;

        // Placeholder
        const placeholderOption = document.createElement("option");
        placeholderOption.value = "";
        placeholderOption.textContent = param.description || /*"Select an option"*/ "";
        placeholderOption.disabled = true;
        placeholderOption.selected = true;
        placeholderOption.hidden = true;
        dropdown.appendChild(placeholderOption);

        // Render true/false; respect custom options if provided
        const boolOptions = (param.options && param.options.length)
          ? param.options.map((v) => String(v).toLowerCase() === "true")
          : [true, false];

        boolOptions.forEach((val) => {
          const opt = document.createElement("option");
          opt.value = val ? "true" : "false";     // API value (string)
          opt.textContent = val ? "True" : "False"; // UI label
          dropdown.appendChild(opt);
        });

        // Default value: accept "true"/"false" or boolean true/false
        if (typeof param.defaultValue !== "undefined" && param.defaultValue !== "") {
          const dv = typeof param.defaultValue === "boolean"
            ? (param.defaultValue ? "true" : "false")
            : String(param.defaultValue).toLowerCase();
          if (dv === "true" || dv === "false") dropdown.value = dv;
        }

        paramWrapper.appendChild(dropdown);

      } else if (param.type === "date") {
        // DATE (local offset logic preserved)
        const input = document.createElement("input");
        input.type = "date";
        input.id = `body-param-${param.name}`;
        input.className = "body-param-input";
        input.dataset.path = param.path;
        input.dataset.type = param.type;

        if (param.defaultValue === "") {
          input.placeholder = param.description || "mm/dd/yyyy";
          input.classList.add("placeholder-style");
        } else if (typeof param.defaultValue === "string" && /^[+-]?\d+$/.test(param.defaultValue)) {
          const daysOffset = parseInt(param.defaultValue, 10);
          input.value = formatLocalYMD(daysOffset); // local date
        } else if (param.defaultValue) {
          input.value = param.defaultValue;
        }

        paramWrapper.appendChild(input);

      } else if (param.type === "integer") {
        // INTEGER (aligned like text)
        paramWrapper.classList.add("body-int-wrapper");

        const input = document.createElement("input");
        input.type = "number";
        input.step = "1";
        input.inputMode = "numeric";
        input.pattern = "\\d*";
        input.id = `body-param-${param.name}`;
        input.className = "body-param-input body-int-input";
        input.dataset.path = param.path;
        input.dataset.type = param.type;

        if (Number.isInteger(param.defaultValue)) {
          input.value = String(param.defaultValue);
        } else if (typeof param.defaultValue === "string" && /^\d+$/.test(param.defaultValue)) {
          input.value = param.defaultValue;
        } else {
          input.placeholder = param.description || "Enter integer";
        }

        paramWrapper.appendChild(input);

      } else {
        // PLAIN TEXT (aligned right like query)
        paramWrapper.classList.add("body-text-wrapper");

        const input = document.createElement("input");
        input.type = "text";
        input.id = `body-param-${param.name}`;
        input.className = "body-param-input body-text-input";
        input.dataset.path = param.path;
        input.dataset.type = param.type;

        if (param.defaultValue !== undefined && param.defaultValue !== "") {
          input.value = param.defaultValue;
        } else {
          input.placeholder = param.description || "Enter value";
        }

        paramWrapper.appendChild(input);
      }

      bodyParamContainer.appendChild(paramWrapper);
    });

  } catch (error) {
    appLogger.error("Error populating Body Parameters:", error);
  }
}

// Parameter Select Label Value Pairs
function normalizeOptions(options) {
  return (options || []).map(opt => {
    if (typeof opt === "string") return { label: opt, value: opt };
    const label = (opt && typeof opt.label === "string") ? opt.label : String(opt?.value ?? "");
    const value = (opt && typeof opt.value !== "undefined") ? String(opt.value) : label;
    return { label, value };
  });
}

// Stylize Ad-Hoc APIs
function applyDynamicStyles() {
    // get dynamically generated elements
    const endpointInput = document.getElementById("adhoc-endpoint");
    const bodyTextarea = document.getElementById("adhoc-body");

    // add classes if necessary
    if (endpointInput) {
        endpointInput.classList.add("query-param-input");
    }

    if (bodyTextarea) {
        bodyTextarea.classList.add("json-textarea");
    }
}

// Map User Inputs to Request Profile
function mapUserInputsToRequestProfile(profile, inputs) {
  if (!profile || !inputs) return;

  // helper: set value at dotted path, creating objects as needed
  const setAtPath = (obj, path, val) => {
    if (!path) return;
    const parts = String(path).split(".");
    let cur = obj;
    parts.forEach((p, i) => {
      if (i === parts.length - 1) {
        cur[p] = val;
      } else {
        cur[p] = cur[p] ?? {};
        cur = cur[p];
      }
    });
  };

  // Collect multi-text values by path (we’ll set after we sweep)
  const multiTextBuckets = new Map();

  // First pass: handle everything except multi-select checkbox aggregation
  inputs.forEach((el) => {
    const path = el.dataset.path;
    const type = (el.dataset.type || "").toLowerCase();
    if (!path) return;

    // normalize basic value
    const raw = (el.value ?? "").toString().trim();

    if (type === "multi-text") {
      if (!multiTextBuckets.has(path)) multiTextBuckets.set(path, []);
      if (raw !== "") multiTextBuckets.get(path).push(raw);
      return;
    }

    if (type === "multi-select") {
      // handled after this loop (we need all checkboxes)
      return;
    }

    if (type === "boolean") {
      // accept "true"/"false" or select choice; skip if placeholder/empty
      if (raw === "true" || raw === "false") {
        setAtPath(profile, path, raw === "true");
        return;
      }
      if (el.tagName === "SELECT" && el.value !== "") {
        setAtPath(profile, path, el.value === "true");
      }
      return;
    }

    if (type === "integer") {
      if (raw === "") return; // skip empty
      if (!/^-?\d+$/.test(raw)) {
        throw new Error(`"${raw}" is not a valid integer for ${path}`);
      }
      setAtPath(profile, path, parseInt(raw, 10));
      return;
    }

    if (type === "date") {
      // Skip empty or placeholder
      const isPlaceholder =
        /^mm\/dd\/yyyy$/i.test(raw) ||
        (typeof el.placeholder === "string" && raw === el.placeholder);
      if (raw === "" || isPlaceholder) return;
      // <input type="date"> gives YYYY-MM-DD; keep as-is
      setAtPath(profile, path, raw);
      return;
    }

    if (type === "select") {
      // regular select (e.g., symbolic period): skip if placeholder/empty
      if (raw === "") return;
      setAtPath(profile, path, raw);
      return;
    }

    // default: plain text
    if (raw === "") return;
    setAtPath(profile, path, raw);
  });

  // Apply multi-text arrays (only if any non-empty values)
  for (const [path, arr] of multiTextBuckets.entries()) {
    if (arr.length) setAtPath(profile, path, arr);
  }

  // Aggregate multi-select checkboxes by path (checked only)
  const byPath = {};
  inputs.forEach((el) => {
    if ((el.dataset.type || "").toLowerCase() !== "multi-select") return;
    const path = el.dataset.path;
    if (!path) return;
    (byPath[path] ||= []);
    if (el.checked) byPath[path].push(el.value);
  });
  Object.keys(byPath).forEach((path) => {
    const vals = byPath[path];
    if (vals.length) setAtPath(profile, path, vals);
  });
}

// Clean Built Request Profile of Empty/NUll Fields
function pruneRequestBody(node) {
  const isEmptyish = (v) => v === "" || v === null || typeof v === "undefined";

  if (Array.isArray(node)) {
    for (let i = node.length - 1; i >= 0; i--) {
      const v = node[i];
      if (v && typeof v === "object") {
        if (pruneRequestBody(v)) node.splice(i, 1);
      } else if (isEmptyish(v) || (typeof v === "string" && v.trim() === "")) {
        node.splice(i, 1);
      }
    }
    return node.length === 0;
  }

  if (node && typeof node === "object") {
    for (const k of Object.keys(node)) {
      const v = node[k];
      if (Array.isArray(v)) {
        if (pruneRequestBody(v)) delete node[k];
      } else if (v && typeof v === "object") {
        if (pruneRequestBody(v)) delete node[k];
      } else if (isEmptyish(v) || (typeof v === "string" && v.trim() === "")) {
        delete node[k];
      }
    }
    return Object.keys(node).length === 0;
  }

  return false;
}

// Clear Response UI For New Data
function clearApiResponse() {
    const responseSection = document.getElementById("response-section");
    if (responseSection) {
        responseSection.innerHTML = "<pre>Awaiting API Response...</pre>";
    }
}

// Wait For New Access Token If Needed
async function waitForUpdatedToken(clienturl, maxRetries = 5, delayMs = 1000) {
    for (let i = 0; i < maxRetries; i++) {
        await new Promise((resolve) => setTimeout(resolve, delayMs)); // wait for storage update
        let updatedData = await loadClientData();
        let updatedClientData = updatedData[clienturl] || {};

        if (updatedClientData.accesstoken) {
            appLogger.info("New access token retrieved:", updatedClientData.accesstoken);
            return updatedClientData;
        }

        appLogger.info(`Retry ${i + 1}/${maxRetries}: Token not available yet...`);
    }

    throw new Error("Failed to retrieve updated access token after multiple attempts.");
}
	
// API Entry Selector
async function handleApiSelection(selectedKey) {
  if (selectedKey === "__VIEW_MY_APIS__") {
    await populateApiDropdownMyApis();
    clearApiResponse?.();
    clearParameters?.();
    clearDevLinkBanner();
    applyDynamicStyles?.();
    return;
  }
  if (selectedKey === "__VIEW_PUBLIC_APIS__") {
    await populateApiDropdownPublic();
    clearApiResponse?.();
    clearDevLinkBanner();
    clearParameters?.();
    applyDynamicStyles?.();
    return;
  }
  // open my apis manager overlay
  if (selectedKey === "__MANAGE_MY_APIS__") {
    await openMyApisManager();
    // reset selector back to placeholder so it doesn't look like a real API
    const sel = document.getElementById("api-selector");
    if (sel) sel.value = "";
    return;
  }
  if (!selectedKey || selectedKey === "__EMPTY__") return;

  clearApiResponse?.();
  clearParameters?.();

  // saved item?
  if (HERMES_MYAPIS_MODE && selectedKey.startsWith("myapi:")) {
    const id = selectedKey.slice(6);
    const list = await getSavedMyApis();
    const item = list.find(x => x.id === id);
    // render like Ad-Hoc
    await renderSavedAsAdHoc(item);
    applyDynamicStyles?.();
    return;
  }

  // public library item
  await populatePathParameters(selectedKey);
  await populateQueryParameters(selectedKey);
  await populateBodyParameters(selectedKey);
  applyDynamicStyles?.();
}

// Helper To Render Saved My API Into AD-Hoc UI
async function renderSavedAsAdHoc(item) {
  const queryContainer = document.getElementById("query-parameters-container");
  const bodyContainer  = document.getElementById("body-parameters-container");
  if (!queryContainer || !bodyContainer) return;

  // endpoint field (Ad-Hoc style)
  queryContainer.innerHTML = "";
  const qh = document.createElement("div");
  qh.className = "parameter-header";
  qh.textContent = "Endpoint URL with Query Parameters";
  queryContainer.appendChild(qh);

  const ep = document.createElement("input");
  ep.type = "text";
  ep.id = "adhoc-endpoint";
  ep.classList.add("query-param-input");
  ep.placeholder = "/v1/endpoint?queryParam=value";
  ep.value = item?.endpoint || "";
  queryContainer.appendChild(ep);

  // body field for post methods only
  bodyContainer.innerHTML = "";
  if (String(item?.method).toUpperCase() === "POST") {
    const bh = document.createElement("div");
    bh.className = "parameter-header";
    bh.textContent = "Full JSON Body";
    bodyContainer.appendChild(bh);

    const ta = document.createElement("textarea");
    ta.id = "adhoc-body";
    ta.className = "json-textarea";
    ta.placeholder = "Enter full JSON body here...";
    ta.value = item?.body || "";
    bodyContainer.appendChild(ta);
  }
}

// Save Request Button
async function onSaveRequestClick() {
  try {
    const sel = document.getElementById("api-selector");
    const selectedKey = sel?.value || "";

    let method = "GET";
    let endpoint = "";
    let bodyStr = "";

    if (HERMES_MYAPIS_MODE && selectedKey.startsWith("myapi:")) {
      // editing an existing saved item → read current inputs
      const id = selectedKey.slice(6);
      const list = await getSavedMyApis();
      const item = list.find(x => x.id === id);
      if (!item) return;

      method = item.method.toUpperCase();
      endpoint = (document.getElementById("adhoc-endpoint")?.value || "").trim();
      if (method === "POST") {
        bodyStr = (document.getElementById("adhoc-body")?.value || "").trim();
      }

      const name = prompt("Rename and save: (120 Character Limit)", item.name)?.trim();
      if (!name) return;
      const MAX_NAME = 120;
      if (name.length > MAX_NAME) {
        alert(`Name is too long (${name.length}). Please keep it under ${MAX_NAME} characters.`);
        return;
      }
      item.name = name;
      item.method = method;
      item.endpoint = endpoint;
      item.body = bodyStr;
      item.updatedAt = new Date().toISOString();
      await setSavedMyApis(list);

      setButtonTempText?.(document.getElementById("save-request"), "Saved!");
      return;
    }

    // ad-hoc get/post → build from fields
    if (selectedKey === "adHocGet" || selectedKey === "adHocPost") {
      method = selectedKey === "adHocPost" ? "POST" : "GET";
      endpoint = (document.getElementById("adhoc-endpoint")?.value || "").trim();
      if (!endpoint) { alert("Please enter an endpoint to save."); return; }
      if (method === "POST") {
        bodyStr = (document.getElementById("adhoc-body")?.value || "").trim();
      }
    } else {
      // public library item → build url with query params and body from your current ui
      const apiLib = await loadApiLibrary();
      const api = apiLib[selectedKey];
      if (!api) { alert("Selected API not found."); return; }

      method = (api.method || "GET").toUpperCase();
      endpoint = api.url;
      // Replace path params
      try {
        endpoint = buildUrlWithPathParams(api.url, api);
      } catch (e) {
        alert(e.message || "Missing path parameters.");
        return;
      }

      if (method === "GET") {
        const params = new URLSearchParams();
        document.querySelectorAll("#query-parameters-container .query-param-input").forEach(inp => {
          const v = (inp.value || "").trim();
          if (!v) return;
          const k = (inp.id || "").replace(/^query-/, "") || inp.name || "";
          if (k) params.append(k, v);
        });
        const qs = params.toString();
        if (qs) endpoint += "?" + qs;
      } else if (method === "POST" && api.requestProfile) {
        const tmpl = JSON.parse(JSON.stringify(api.requestProfile));
        const bodyHost = document.getElementById("body-parameters-container");
        const inputs = Array.from(bodyHost.querySelectorAll("[data-path]"));
        mapUserInputsToRequestProfile(tmpl, inputs);
        bodyStr = JSON.stringify(tmpl, null, 2);
      }
    }

    const defaultName = `${method} ${endpoint.split("?")[0] || ""}`;
    const name = prompt("Save request as: (120 Character Limit)", defaultName)?.trim();
    if (!name) return;

    const MAX_NAME = 120;
    if (name.length > MAX_NAME) {
      alert(`Name is too long (${name.length}). Please keep it under ${MAX_NAME} characters.`);
      return;
    }

    const list = await getSavedMyApis();
    const entry = {
      id: genId(),
      name,
      method,
      endpoint,
      body: bodyStr,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    list.push(entry);
    await setSavedMyApis(list);

    // Switch to My APIs mode, repopulate, select the new one, and render
    await populateApiDropdownMyApis();
    const newKey = `myapi:${entry.id}`;
    const dd = document.getElementById("api-selector");
    dd.value = newKey;
    await handleApiSelection(newKey);
    applyDynamicStyles?.();

    setButtonTempText?.(document.getElementById("save-request"), "Saved!");
  } catch (e) {
    console.error(e);
    setButtonFailText?.(document.getElementById("save-request"), "Save Failed");
  }
}

// Reset Parameters Button
async function onResetParamsClick() {
  try {
    await resetCurrentApiParameters();
  } catch (e) {
    console.error("Reset Parameters failed:", e);
    alert("Unable to reset parameters. See console for details.");
  }
}

// Re-render Currently Selected API's Parameter UI From Defaults
async function resetCurrentApiParameters() {
  // 1) determine selected api
  const apiSel = document.getElementById("api-selector");
  const selectedApiKey = apiSel?.value || "";
  if (!selectedApiKey || selectedApiKey === "Select API...") {
    alert("Select an API first to reset its parameters.");
    return;
  }

  // 2) clear current param ui
  if (typeof clearParameters === "function") {
    clearParameters();
  } else {
    const q = document.getElementById("query-parameters-container");
    const b = document.getElementById("body-parameters-container");
    const p = document.getElementById("path-parameters-container");
    if (q) q.innerHTML = "";
    if (b) b.innerHTML = "";
    if (p) p.innerHTML = "";
  }

  // (optional) clear the last response panel
  /*if (typeof clearApiResponse === "function") {
    clearApiResponse();
  }*/

  // 3) repopulate from library defaults
  await populatePathParameters(selectedApiKey);
  await populateQueryParameters(selectedApiKey);
  await populateBodyParameters(selectedApiKey);

  // 4) re-apply any dynamic styles
  if (typeof applyDynamicStyles === "function") {
    applyDynamicStyles();
  }

  // 5) if this is ad-hoc, ensure blank fields
  if (selectedApiKey === "adHocGet") {
    const ep = document.getElementById("adhoc-endpoint");
    if (ep) ep.value = "";
  }
  if (selectedApiKey === "adHocPost") {
    const ep = document.getElementById("adhoc-endpoint");
    const tb = document.getElementById("adhoc-body");
    if (ep) ep.value = "";
    if (tb) tb.value = "";
  }
}

// Execute API Call With Multi-Call Support
async function executeApiCall() {
  const button = document.getElementById("execute-api");
  let animation;

  try {
    clearApiResponse();
    appLogger.info("Executing API call...");

    // start loading animation and store both interval and original text
    animation = startLoadingAnimation(button);

    if (!(await isValidSession())) {
      alert("Requires a valid ADP Workforce Manager session.");
      throw new Error("Invalid session");
    }

    const apiDropdown = document.getElementById("api-selector");
    const selectedApiKey = apiDropdown?.value;
    if (!selectedApiKey || selectedApiKey === "Select API...") {
      alert("Please select an API to execute.");
      throw new Error("No API selected");
    }

    // detect saved my api entry (myapi:<id>)
    let savedEntry = null;
    if (selectedApiKey.startsWith("myapi:")) {
      const id = selectedApiKey.slice(6);
      const { hermes_myapis } = await new Promise((resolve) =>
        chrome.storage.local.get(["hermes_myapis"], resolve)
      );
      const list = hermes_myapis || [];
      savedEntry = list.find((x) => x.id === id) || null;
      if (!savedEntry) {
        alert("Saved request not found.");
        throw new Error("Saved request not found");
      }
    }

    const clienturl = await getClientUrl();
    let data = await loadClientData();
    let clientData = data[clienturl] || {};

    if (!clientData.accesstoken || new Date(clientData.expirationdatetime) < new Date()) {
      console.log("Access token expired or missing. Fetching a new token...");
      await fetchToken();
      clientData = await waitForUpdatedToken(clienturl);
    }

    const accessToken = clientData.accesstoken;

    // shared variables
    let fullUrl = "";
    let requestBody = null;
    let requestMethod = "GET";

    // branch a: saved My API (ad-hoc style)
    if (savedEntry) {
      requestMethod = String(savedEntry.method || "GET").toUpperCase();

      // prefer current ui values (if user modified), fallback to saved values
      const epUi = document.getElementById("adhoc-endpoint")?.value?.trim();
      const bodyUi = document.getElementById("adhoc-body")?.value;

      const endpoint = (epUi || savedEntry.endpoint || "").trim();
      if (!endpoint) {
        alert("Please provide an endpoint URL.");
        throw new Error("Empty saved endpoint");
      }
      fullUrl = clientData.apiurl + endpoint;

      if (requestMethod === "POST") {
        const raw = (typeof bodyUi === "string" ? bodyUi : savedEntry.body || "").trim();
        if (!raw) {
          alert("Please provide a JSON body.");
          throw new Error("Empty JSON body (saved)");
        }
        try {
          requestBody = JSON.parse(raw);
          pruneRequestBody(requestBody);
        } catch {
          alert("Invalid JSON body. Please correct it.");
          throw new Error("Invalid JSON format (saved)");
        }
      }

      // save request details (so request details works with my apis)
      lastRequestDetails = {
        method: requestMethod,
        url: fullUrl,
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json",
        },
        body: requestBody ? JSON.stringify(requestBody, null, 2) : null,
      };

      const response = await fetch(fullUrl, {
        method: requestMethod,
        headers: lastRequestDetails.headers,
        body: lastRequestDetails.body,
      });

      const responseText = await response.text();
      let result;
      try { result = JSON.parse(responseText); } catch { result = { error: responseText }; }

      appLogger.info("API Response:", result);
      displayApiResponse(result, selectedApiKey);

      if (animation?.interval) clearInterval(animation.interval);
      if (response.ok) setButtonTempText(button, "Success!", 2000, animation.originalText);
      else setButtonFailText(button, "Failed!", 2000, animation.originalText);
      return; // done with saved branch
    }

    // branch B: public library path
    const apiLibrary = await loadApiLibrary();
    const selectedApi = apiLibrary[selectedApiKey];
    if (!selectedApi) {
      alert("Selected API not found in the library.");
      throw new Error("API not found");
    }

    requestMethod = (selectedApi.method || "GET").toUpperCase();
    fullUrl = clientData.apiurl + selectedApi.url;
    // Replace {param} tokens
    const pathUrl = buildUrlWithPathParams(selectedApi.url, selectedApi);
    fullUrl = clientData.apiurl + pathUrl;


    // handle query parameters for standard get requests
    if (requestMethod === "GET") {
      const queryParams = new URLSearchParams();
      const queryInputs = document.querySelectorAll("#query-parameters-container .query-param-input");
      queryInputs.forEach((input) => {
        if (input.value.trim() !== "" && input.value.trim() !== input.placeholder) {
          queryParams.append(input.id.replace("query-", ""), input.value.trim());
        }
      });
      if (queryParams.toString()) fullUrl += "?" + queryParams.toString();
    }

    // handle ad-hoc requests from library keys (adHocGet/adHocPost)
    if (selectedApiKey === "adHocGet" || selectedApiKey === "adHocPost") {
      const endpointInput = document.getElementById("adhoc-endpoint");
      if (!endpointInput || !endpointInput.value.trim()) {
        alert("Please provide an endpoint URL.");
        throw new Error("Empty ad-hoc endpoint");
      }
      fullUrl = clientData.apiurl + endpointInput.value.trim();
    }

    // handle pre-request logic if needed
    if (selectedApi.preRequest) {
      appLogger.info(`Executing pre-request: ${selectedApi.preRequest.apiKey}`);

      const preRequestApi = apiLibrary[selectedApi.preRequest.apiKey];
      const preRequestUrl = clientData.apiurl + preRequestApi.url;

      const preResponse = await fetch(preRequestUrl, {
        method: "GET",
        headers: { Authorization: `Bearer ${accessToken}` }
      });

      if (!preResponse.ok) {
        const errorText = await preResponse.text();
        displayApiResponse({ error: errorText }, selectedApiKey);
        throw new Error(`Pre-request failed. HTTP status: ${preResponse.status}`);
      }

      const preResult = await preResponse.json();
      appLogger.info("Pre-request Response:", preResult);

      const { field, match, mapTo, ["data-path"]: dataPath } = selectedApi.preRequest.responseFilter;
      let mappedValues = preResult.filter(item => item[field] === match).map(item => item[mapTo]);

      const maxLimit = selectedApi.bodyParameters.find(p => p.name === "qualifiers")?.validation?.maxEntered || 1000;
      if (mappedValues.length > maxLimit) {
        alert(`Only the first ${maxLimit} entries will be used due to API limitations.`);
        mappedValues = mappedValues.slice(0, maxLimit);
      }

      appLogger.info("Mapped Values (Limited):", mappedValues);

      // dynamically insert mapped values into requestBody using the correct datapath
      requestBody = {};
      const pathParts = dataPath.split(".");
      let currentLevel = requestBody;
      pathParts.forEach((part, index) => {
        if (index === pathParts.length - 1) currentLevel[part] = mappedValues;
        else { currentLevel[part] = currentLevel[part] || {}; currentLevel = currentLevel[part]; }
      });
    } else {
      // handle request body for regular post apis
      if (requestMethod === "POST") {
        if (selectedApiKey === "adHocPost") {
          const bodyInput = document.getElementById("adhoc-body");
          if (!bodyInput || !bodyInput.value.trim()) {
            alert("Please provide a JSON body.");
            throw new Error("Empty JSON body");
          }
          try {
            requestBody = JSON.parse(bodyInput.value.trim());
          } catch (error) {
            alert("Invalid JSON body. Please correct it.");
            throw new Error("Invalid JSON format");
          }
        } else if (selectedApi.requestProfile) {
          const profileTemplate = JSON.parse(JSON.stringify(selectedApi.requestProfile));
          const bodyParamsContainer = document.getElementById("body-parameters-container");
          const paramInputs = Array.from(bodyParamsContainer.querySelectorAll("[data-path]"));
          mapUserInputsToRequestProfile(profileTemplate, paramInputs);
          pruneRequestBody(profileTemplate);
          requestBody = profileTemplate;
        }
      }
    }

    appLogger.info("Final Request Body:", JSON.stringify(requestBody, null, 2));

    // save request details for the request details button
    lastRequestDetails = {
      method: requestMethod,
      url: fullUrl,
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
      body: requestBody ? JSON.stringify(requestBody, null, 2) : null,
    };

    const response = await fetch(fullUrl, {
      method: requestMethod,
      headers: lastRequestDetails.headers,
      body: lastRequestDetails.body,
    });

    const responseText = await response.text();
    let result;
    try { result = JSON.parse(responseText); } catch { result = { error: responseText }; }

    appLogger.info("API Response:", result);
    displayApiResponse(result, selectedApiKey);

    if (animation?.interval) clearInterval(animation.interval);
    if (response.ok) setButtonTempText(button, "Success!", 2000, animation.originalText);
    else setButtonFailText(button, "Failed!", 2000, animation.originalText);

  } catch (error) {
    appLogger.error("Error executing API call:", error);
    alert(`API call failed: ${error.message}`);
    displayApiResponse({ error: error.message }, "Error");

    if (animation?.interval) clearInterval(animation.interval);
    setButtonFailText(button, "Failed!", 2000, animation.originalText);
  }
}

// Display API Response (Default = Raw View)
async function displayApiResponse(response, apiKey) {
  const responseSection = document.getElementById("response-section");
  window.lastApiResponseObject = response; // stash for popout/toggle

  // preserve/create popout button
  let popoutButton = document.getElementById("popout-response");
  if (!popoutButton) {
    popoutButton = document.createElement("button");
    popoutButton.id = "popout-response";
    popoutButton.className = "btn3";
    popoutButton.innerHTML = `
      Popout Response 
      <img src="icons/external-link.png" alt="Popout" class="btn-icon">
    `;
    popoutButton.addEventListener("click", popoutResponse);
    responseSection.prepend(popoutButton);
  }

  // load api library and set up export csv button if needed
  const apiLibrary = await loadApiLibrary();
  appLogger.info("Raw API Key from executeApiCall:", apiKey);
  appLogger.info("Available API Keys in Library:", Object.keys(apiLibrary));
  const selectedApi = apiLibrary[apiKey];
  if (!selectedApi) {
    console.log("API Key Not Found in Library:", apiKey);
  } else {
    appLogger.info("Retrieved API Object:", selectedApi);
    appLogger.info("Checking ExportMap for:", apiKey, selectedApi?.exportMap);
  }

  if (selectedApi?.exportMap) {
    let exportCsvButton = document.getElementById("export-api-csv");
    if (!exportCsvButton) {
      exportCsvButton = document.createElement("button");
      exportCsvButton.id = "export-api-csv";
      exportCsvButton.className = "btn3";
      exportCsvButton.innerHTML = `
        Export CSV
        <img src="icons/export-csv.png" alt="CSV" class="btn-icon">
      `;
      exportCsvButton.addEventListener("click", () => {
        appLogger.info("Export CSV button clicked!");
        exportApiResponseToCSV(response, selectedApi.exportMap, apiKey);
      });
      responseSection.appendChild(exportCsvButton);
    }
  }

  // ensure tree/raw toggle exists (default = raw)
  ensureViewToggle();

  // clear prior render
  [...responseSection.querySelectorAll('.json-tree, pre')].forEach(n => n.remove());

  // raw by default
  const pre = document.createElement('pre');
  pre.textContent = JSON.stringify(response, null, 2);
  responseSection.appendChild(pre);

  // set toggle button state to raw
  const toggle = document.getElementById('toggle-view');
  if (toggle) {
    toggle.dataset.mode = 'raw';
    toggle.textContent = 'Tree View';
  }

  // enable download button
  const downloadButton = document.getElementById("download-response");
  if (downloadButton) {
    downloadButton.disabled = false;
    downloadButton.onclick = () => downloadApiResponse(response, apiKey);
  }
}

// JSON Tree View Renderer
function renderJsonTree(data, rootEl, {collapsedDepth = 1} = {}) {
  rootEl.innerHTML = ''
  const el = buildNode(data, undefined, 0, collapsedDepth)
  rootEl.appendChild(el)
}

// JSON Tree View Node Builder
function buildNode(value, key, depth, collapsedDepth) {
  const isObj = v => v && typeof v === 'object'
  if (isObj(value)) {
    const details = document.createElement('details')
    details.open = depth < collapsedDepth

    const summary = document.createElement('summary')
    summary.textContent = key != null
      ? `${key}: ${Array.isArray(value) ? '[]' : '{}'}`
      : (Array.isArray(value) ? '[]' : '{}')
    details.appendChild(summary)

    const keys = Array.isArray(value) ? value.keys() : Object.keys(value)
    for (const k of keys) {
      const childKey = Array.isArray(value) ? k : k
      const childVal = Array.isArray(value) ? value[k] : value[k]
      details.appendChild(buildNode(childVal, childKey, depth + 1, collapsedDepth))
    }
    return details
  } else {
    const row = document.createElement('div')
    row.className = 'json-leaf'
    row.textContent = key != null ? `${key}: ${formatScalar(value)}` : formatScalar(value)
    return row
  }
}

// Pretty-Print Leaf Values For The JSON Tree
function formatScalar(v) {
  if (typeof v === 'string') return `"${v}"`
  if (v === null) return 'null'
  return String(v)
}

// API Response Raw / Tree View Toggle
function ensureViewToggle() {
  const section = document.getElementById('response-section');
  let btn = document.getElementById('toggle-view');
  if (btn) return;

  btn = document.createElement('button');
  btn.id = 'toggle-view';
  btn.className = 'btn3';
  btn.dataset.mode = 'raw';   // default mode
  btn.textContent = 'Tree View';
  section.prepend(btn);

  btn.onclick = () => {
    const mode = btn.dataset.mode;
    // clear current render
    [...section.querySelectorAll('.json-tree, pre')].forEach(n => n.remove());

    if (mode === 'raw') {
      // switch to tree
      const tree = document.createElement('div');
      tree.className = 'json-tree';
      section.appendChild(tree);
      renderJsonTree(window.lastApiResponseObject ?? {}, tree, { collapsedDepth: 1 });
      btn.dataset.mode = 'tree';
      btn.textContent = 'Raw View';
    } else {
      // switch back to raw
      const pre = document.createElement('pre');
      pre.textContent = JSON.stringify(window.lastApiResponseObject ?? {}, null, 2);
      section.appendChild(pre);
      btn.dataset.mode = 'raw';
      btn.textContent = 'Tree View';
    }
  };
}

// Download API Response Button
async function downloadApiResponse(response, apiName) {
    const sanitizedApiName = apiName.replace(/[^a-zA-Z0-9_-]/g, "_"); // Sanitize filename
    const defaultFileName = `${sanitizedApiName || "api_response"}.json`;

    if (window.showSaveFilePicker) {
        try {
            // Modern method: File System Access API
            const fileHandle = await window.showSaveFilePicker({
                suggestedName: defaultFileName,
                types: [
                    {
                        description: "JSON Files",
                        accept: { "application/json": [".json"] },
                    },
                ],
            });

            // write file content
            const writableStream = await fileHandle.createWritable();
            await writableStream.write(JSON.stringify(response, null, 2));
            await writableStream.close();

            appLogger.info("File successfully saved.");
        } catch (error) {
            if (error.name !== "AbortError") {
                appLogger.error("Error saving file:", error);
                alert("Failed to save the file.");
            }
        }
    } else {
        // fallback: trigger file download using Blob and anchor element
        appLogger.info("File System Access API not supported, using fallback method.");

        const blob = new Blob([JSON.stringify(response, null, 2)], { type: "application/json" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = defaultFileName;
        a.click();
        URL.revokeObjectURL(url);

        appLogger.info("File downloaded using fallback method.");
    }
}

// Copy Response Button
function copyApiResponse() {
    const button = document.getElementById("copy-api-response");
    const responseSection = document.getElementById("response-section");

    // find the first <pre> or <code> block that contains the json response
    const jsonElement = responseSection?.querySelector("pre, code");

    if (jsonElement) {
        const responseContent = jsonElement.innerText.trim();

        if (responseContent) {
            navigator.clipboard.writeText(responseContent)
                .then(() => {
                    setButtonTempText(button, "Copied!");
                })
                .catch((err) => {
                    appLogger.info("Failed to copy API response:", err);
                    setButtonFailText(button, "Copy Failed!");
                });
        } else {
            appLogger.info("No valid JSON response found.");
            setButtonFailText(button, "No JSON!");
        }
    } else {
        appLogger.info("No API Response exists. Send a request first.");
        setButtonFailText(button, "No Response!");
    }
}

// Request Details Button
function showRequestDetails() {
    if (!lastRequestDetails) {
        const noDetailsHtml = `
            <html>
            <head>
                <title>No Request Details</title>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        padding: 20px;
                        margin: 0;
                    }
                    h1 {
                        color: #ff0000;
                    }
                </style>
            </head>
            <body>
                <h1>No request details available.</h1>
            </body>
            </html>
        `;

        const noDetailsWindow = window.open("", "_blank", "width=400,height=300");
        noDetailsWindow.document.write(noDetailsHtml);
        noDetailsWindow.document.close();
        return;
    }

    const requestDetailsHtml = `
        <html>
        <head>
            <title>Request Details</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    padding: 20px;
                    margin: 0;
                    line-height: 1.6;
                }
                h1 {
                    color: #0059B3;
                }
                pre {
                    background: #f4f4f4;
                    border: 1px solid #ddd;
                    padding: 10px;
                    overflow-x: auto;
                }
            </style>
        </head>
        <body>
            <h1>Request Details</h1>
            <p><strong>Method:</strong> ${lastRequestDetails.method}</p>
            <p><strong>URL:</strong> ${lastRequestDetails.url}</p>
            <p><strong>Headers:</strong></p>
            <pre>${JSON.stringify(lastRequestDetails.headers, null, 2)}</pre>
            <p><strong>Body:</strong></p>
            <pre>${lastRequestDetails.body || "No body"}</pre>
        </body>
        </html>
    `;

    const detailsWindow = window.open("", "_blank", "width=600,height=400");
    detailsWindow.document.write(requestDetailsHtml);
    detailsWindow.document.close();
}

// Popout Button (API Response)
function popoutResponse() {
  const data = window.lastApiResponseObject;
  if (!data) {
    const noResponseHtml = `
      <html><head><title>No Response</title>
      <style>
        body { font-family: Arial, sans-serif; padding: 20px; margin: 0; }
        h1 { color: #ff0000; }
      </style></head>
      <body>
        <h1>No response available.</h1>
        <p>Please send an API request to generate a response.</p>
      </body></html>`;
    const w = window.open("", "_blank", "width=400,height=300");
    w.document.write(noResponseHtml);
    w.document.close();
    return;
  }

  const mode = document.getElementById('toggle-view')?.dataset.mode || 'raw';

  if (mode === 'raw') {
    // RAW popout
    const responseHtml = `
      <html><head><title>API Response</title>
      <style>
        body { font-family: Arial, sans-serif; padding: 20px; margin: 0; line-height: 1.6; }
        h1 { color: #0059B3; }
        pre { background: #f4f4f4; border: 1px solid #ddd; padding: 10px; overflow-x: auto; }
      </style></head>
      <body>
        <h1>API Response</h1>
        <pre>${escapeHtml(JSON.stringify(data, null, 2))}</pre>
      </body></html>`;
    const w = window.open("", "_blank", "width=800,height=900");
    w.document.write(responseHtml);
    w.document.close();
  } else {
    // TREE popout (no inline script: pre-render HTML in the parent)
    const container = document.createElement('div');
    container.className = 'json-tree';
    // reuse your existing renderer to build DOM in this temp container
    renderJsonTree(data, container, { collapsedDepth: 1 });

    // serialize the built tree to static HTML
    const treeHtml = container.outerHTML;

    const responseHtml = `
      <html><head><title>API Response (Tree)</title>
      <style>
        body { font-family: Arial, sans-serif; padding: 20px; margin: 0; line-height: 1.6; }
        h1 { color: #0059B3; margin-bottom: 10px; }
        .json-tree { font: 12px/1.4 ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; }
        .json-tree details { margin-left: .75rem; }
        .json-tree summary { cursor: pointer; outline: none; }
        .json-tree .json-leaf { margin-left: 1.5rem; white-space: pre-wrap; }
      </style></head>
      <body>
        <h1>API Response (Tree)</h1>
        ${treeHtml}
      </body></html>`;
    const w = window.open("", "_blank", "width=900,height=1000");
    w.document.write(responseHtml);
    w.document.close();
  }
}

// Helper for RAW Popout To Avoid Breaking HTML
function escapeHtml(s) {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

// Export JSON Response to CSV Button
async function exportApiResponseToCSV(response, apiKey) {
    appLogger.info("Exporting API Response to CSV...");
    appLogger.info("API Key Received for Export:", apiKey);
    appLogger.info("Full API Response:", response);

    if (!response || (Array.isArray(response) && response.length === 0)) {
        alert("No data available to export.");
        return;
    }

    // extract array if the response is an object with a nested array
    let extractedArray = response;
    if (!Array.isArray(response)) {
        for (const key in response) {
            if (Array.isArray(response[key])) {
                extractedArray = response[key];
                appLogger.info(`Extracted nested array from key: ${key}`);
                break;
            }
        }
    }

    if (!Array.isArray(extractedArray) || extractedArray.length === 0) {
        alert("No valid array data found for export.");
        return;
    }

    // load api library
    const apiLibrary = await loadApiLibrary();
    appLogger.info("Loaded API Library for Validation:", apiLibrary);

    // set the file name based on the api key
    const safeApiName = apiKey ? apiKey : "api-response"; // ensure safe fallback
    appLogger.info("CSV File Name Will Be:", safeApiName);

    let expandedHeaders = new Set();
    let expandedData = [];

    // **recursive function to flatten objects**
    function flattenObject(obj, parentKey = "") {
        let flatRow = {};
        let arrayFields = {};

        Object.entries(obj).forEach(([key, value]) => {
            const newKey = parentKey ? `${parentKey}.${key}` : key;

            if (Array.isArray(value)) {
                arrayFields[newKey] = value;
            } else if (typeof value === "object" && value !== null) {
                // **recursively flatten nested objects**
                const nestedFlat = flattenObject(value, newKey);
                Object.assign(flatRow, nestedFlat.flatRow);
                Object.assign(arrayFields, nestedFlat.arrayFields);
            } else {
                flatRow[newKey] = value;
                expandedHeaders.add(newKey);
            }
        });

        return { flatRow, arrayFields };
    }

    // flatten each object in the array
    extractedArray.forEach(item => {
        const { flatRow, arrayFields } = flattenObject(item);
        const maxRows = Math.max(...Object.values(arrayFields).map(arr => arr.length), 1);

        for (let i = 0; i < maxRows; i++) {
            let rowCopy = { ...flatRow };

            Object.entries(arrayFields).forEach(([field, values]) => {
                if (typeof values[i] === "object" && values[i] !== null) {
                    Object.entries(values[i]).forEach(([subKey, subValue]) => {
                        let subField = `${field}.${subKey}`;
                        rowCopy[subField] = subValue;
                        expandedHeaders.add(subField);
                    });
                } else {
                    rowCopy[field] = values[i] !== undefined ? values[i] : "";
                    expandedHeaders.add(field);
                }
            });

            expandedData.push(rowCopy);
        }
    });

    // remove empty columns
    expandedHeaders = Array.from(expandedHeaders);
    const columnsWithData = expandedHeaders.filter(header =>
        expandedData.some(row => row[header] !== "" && row[header] !== undefined)
    );

    appLogger.info("Final CSV Headers (After Cleanup):", columnsWithData);

    //const csvRows = [columnsWithData.join(",")];
	const csvRows = [`"${columnsWithData.join('","')}"`];


    expandedData.forEach(row => {
        const rowData = columnsWithData.map(header => `"${row[header] !== undefined ? row[header] : ""}"`);
        csvRows.push(rowData.join(","));
    });

    appLogger.info("Final CSV Data:\n", csvRows.join("\n"));

    const csvContent = csvRows.join("\n");
    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");

    // ensure file always saves with the same name (overwrite existing file)
    link.download = `${safeApiName}-export.csv`;
    link.href = url;

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
}
// ================================= //


// ===== MANAGE MY API'S OVERLAY FUNCTIONS ===== //
let MYAPIS_MANAGER_WIRED = false;

// Date Time Stamp
function formatStamp(iso) {
  if (!iso) return "";
  try { return new Date(iso).toLocaleString(); } catch { return iso; }
}

// Dedupe My API
function dedupeById(list) {
  const seen = new Set();
  const out = [];
  for (const x of list || []) {
    if (!x?.id) continue;
    if (seen.has(x.id)) continue;
    seen.add(x.id);
    out.push(x);
  }
  return out;
}

// Manage My API's Button
function toggleManagerButtons() {
  const listEl = document.getElementById("myapis-list");
  const anyChecked = !!listEl?.querySelector('input[type="checkbox"].row-check:checked');
  const delSelBtn = document.getElementById("myapis-delete-selected");
  if (delSelBtn) delSelBtn.disabled = !anyChecked;
}

// Selectable Options For Manage My API's with Dynamic Event Listeners
function wireMyApisManagerOnce() {
  // debug: if the DOM somehow has duplicate controls, warn once.
  const dbgIds = [
    "myapis-list",
    "myapis-select-all",
    "myapis-delete-selected",
    "myapis-delete-all",
    "myapis-cancel",
  ];
  const dups = dbgIds
    .map(id => [id, document.querySelectorAll(`#${CSS.escape(id)}`).length])
    .filter(([_, n]) => n > 1);
  if (dups.length) {
    console.warn("My APIs manager: duplicate controls in DOM:", dups);
  }

  const listHost  = document.getElementById("myapis-list");
  const selAll    = document.getElementById("myapis-select-all");
  const delSelBtn = document.getElementById("myapis-delete-selected");
  const delAllBtn = document.getElementById("myapis-delete-all");
  const cancelBtn = document.getElementById("myapis-cancel");

  // ----- delegated checkbox change on list -----
  if (listHost && !listHost.dataset.wired) {
    listHost.addEventListener("change", (e) => {
      const t = e.target;
      if (!(t instanceof HTMLInputElement)) return;
      if (!t.classList.contains("row-check")) return;
      toggleManagerButtons();
    });
    listHost.dataset.wired = "1";
  }

  // ----- select All -----
  if (selAll && !selAll.dataset.wired) {
    selAll.addEventListener("change", () => {
      listHost?.querySelectorAll("input.row-check").forEach(cb => { cb.checked = selAll.checked; });
      toggleManagerButtons();
    });
    selAll.dataset.wired = "1";
  }

  // ----- delete selected -----
  if (delSelBtn && !delSelBtn.dataset.wired) {
    delSelBtn.addEventListener("click", onDeleteSelectedClick);
    delSelBtn.dataset.wired = "1";
  }

  // ----- delete all -----
  if (delAllBtn && !delAllBtn.dataset.wired) {
    delAllBtn.addEventListener("click", onDeleteAllClick);
    delAllBtn.dataset.wired = "1";
  }

  // ----- close -----
  if (cancelBtn && !cancelBtn.dataset.wired) {
    cancelBtn.addEventListener("click", () => closeMyApisManager());
    cancelBtn.dataset.wired = "1";
  }

  // Keep this too — helps if your file only loads once
  MYAPIS_MANAGER_WIRED = true;
}

// Render My APIs Manager Overlay
async function renderMyApisManager() {
  const list = dedupeById(await getSavedMyApis());   // normalize duplicates
  const host = document.getElementById("myapis-list");
  if (!host) return;
  host.innerHTML = "";

  const selAll   = document.getElementById("myapis-select-all");
  const delSelBtn = document.getElementById("myapis-delete-selected");

  if (!list.length) {
    host.innerHTML = `<div class="myapis-row"><div></div><div class="meta"><div class="title">(No saved APIs)</div></div></div>`;
    // ensure toolbar is reset in the empty case
    if (selAll) selAll.checked = false;
    delSelBtn?.setAttribute("disabled","true");
    return;
  }

  list.forEach((item) => {
    const row = document.createElement("div");
    row.className = "myapis-row";

    const left = document.createElement("div");
    const cb = document.createElement("input");
    cb.type = "checkbox";
    cb.className = "row-check";
    cb.dataset.id = item.id;
    left.appendChild(cb);

    const meta = document.createElement("div");
    meta.className = "meta";

    const title = document.createElement("div");
    title.className = "title";
    title.textContent = `${item.name} (${String(item.method).toUpperCase()})`;

    const subtitle = document.createElement("div");
    subtitle.className = "subtitle";
    subtitle.textContent = item.endpoint || "";

    const stamp = document.createElement("div");
    stamp.className = "stamp";
    stamp.textContent = `Updated: ${formatStamp(item.updatedAt || item.createdAt)}`;

    meta.appendChild(title);
    meta.appendChild(subtitle);
    meta.appendChild(stamp);

    row.appendChild(left);
    row.appendChild(meta);
    host.appendChild(row);
  });

  // reset toolbar state after render
  if (selAll) selAll.checked = false;
  toggleManagerButtons();
}

// Open My APIs Manager Overlay
async function openMyApisManager() {
  wireMyApisManagerOnce();          // attach exactly once
  await renderMyApisManager();

  const overlay = document.getElementById("manage-myapis-overlay");
  if (overlay) overlay.hidden = false;

  // reset controls each open
  const selAll = document.getElementById("myapis-select-all");
  if (selAll) selAll.checked = false;
  document.getElementById("myapis-delete-selected")?.setAttribute("disabled", "true");
}

// Close My APIs Manager Overlay
function closeMyApisManager() {
  const overlay = document.getElementById("manage-myapis-overlay");
  if (overlay) overlay.hidden = true;

  const selAll = document.getElementById("myapis-select-all");
  if (selAll) selAll.checked = false;
  document.getElementById("myapis-delete-selected")?.setAttribute("disabled", "true");
}

// If Current Selection Was Among Deleted Entries, Populate First Remaining Entry Or Placeholder
function clearSelectionIfDeleted(deletedIds) {
  const sel = document.getElementById("api-selector");
  if (!sel) return;
  const val = sel.value || "";
  if (!val.startsWith("myapi:")) return;
  const curId = val.slice(6);
  if (!deletedIds.includes(curId)) return;

  // fallback: placeholder or first remaining item if any
  sel.value = "";
  clearParameters?.();
  clearApiResponse?.();
  applyDynamicStyles?.();
}

// Delete Selected My API's
async function onDeleteSelectedClick() {
  const ids = Array.from(document.querySelectorAll('#myapis-list input.row-check:checked'))
    .map(cb => cb.dataset.id);
  if (!ids.length) return;

  if (!confirm(`Delete ${ids.length} selected saved API(s)? This cannot be undone.`)) return;

  const curList = await getSavedMyApis();
  const next = dedupeById(curList).filter(x => !ids.includes(x.id));
  await setSavedMyApis(next);

  await populateApiDropdownMyApis();
  clearSelectionIfDeleted(ids);
  await renderMyApisManager();
}

// Delete All My API's
async function onDeleteAllClick() {
  const curList = dedupeById(await getSavedMyApis());
  if (!curList.length) return;

  if (!confirm(`Delete ALL (${curList.length}) saved APIs? This cannot be undone.`)) return;

  await setSavedMyApis([]);
  await populateApiDropdownMyApis();
  clearSelectionIfDeleted(curList.map(x => x.id));
  await renderMyApisManager();
}
// ============================================= //


// ===== SESSION FUNCTIONS ===== //
// Remove -nosso From client URL
function createSsoUrl(clientUrl) {
    return clientUrl.replace("-nosso.", ".");
}

// Construct API URL
function toApiUrl(url) {
  if (!url) return "";
  try {
    const u = new URL(url);
    // strip query/hash; normalize path
    let path = u.pathname || "/";
    if (!path.endsWith("/")) path += "/";
    // ensure exactly “…/api” (no trailing slash)
    if (path.endsWith("/api/") || path.endsWith("/api")) {
      path = "/api";
    } else {
      path = path + "api";
    }
    return u.origin + path;
  } catch {
    // fallback if url constructor fails
    let s = (url.split(/[?#]/)[0] || "").replace(/\/+$/, "");
    return s + "/api";
  }
}

// Open URL In Normal Mode
function openURLNormally(url) {
    const newTab = document.createElement("a");
    newTab.href = url;
    newTab.target = "_blank";
    newTab.rel = "noopener noreferrer";
    document.body.appendChild(newTab);
    newTab.click();
    document.body.removeChild(newTab);
}

// Get the base URL (Vanity URL) from active tab and inject 
function getVanityUrl(tabUrl) {
    let url = new URL(tabUrl);
    let hostname = url.hostname;

    // handle the sso url adjustments
    if (hostname.includes(".mykronos.com") && !hostname.includes("-nosso")) {
        if (hostname.includes(".prd.mykronos.com")) {
            hostname = hostname.replace(".prd.mykronos.com", "-nosso.prd.mykronos.com");
        } else if (hostname.includes(".npr.mykronos.com")) {
            hostname = hostname.replace(".npr.mykronos.com", "-nosso.npr.mykronos.com");
        }
    }

    return `${url.protocol}//${hostname}/`;
}

// Validate Session Based On Active Tab URL
async function isValidSession() {
	const clientUrl = await getClientUrl();
	return clientUrl !== null; // if getClientUrl() resolves null, the session is invalid
}

// Validate Current Webpage Is A Valid ADP WFMgr Session
function validateWebPage(url) {
  // first check if we're even on mykronos.com
  if (!url.includes("mykronos.com")) {
    return { valid: false, message: "Invalid Domain" };
  }

  // define invalid URL patterns
  const invalidPatterns = [
    {
      pattern: "mykronos.com/authn/",
      message: "Invalid Login - Authentication Required"
    },
    {
      pattern: "mykronos.com/wfd/unauthorized",
      message: "Invalid Login - Unauthorized Access"
    },
    {
      pattern: /:\/\/adp-developer\.mykronos\.com\//i,
      message: "Developer Portal not supported for API session"
    }
  ];

  // check against invalid patterns
  for (const { pattern, message } of invalidPatterns) {
    if (typeof pattern === 'string' ? url.includes(pattern) : pattern.test(url)) {
      return { valid: false, message };
    }
  }

  // if no invalid patterns matched, the URL is valid
  return { valid: true, message: "Valid" };
}

// Retrieve Current Client URL, Preferring The Linked WFM Tab
async function getClientUrl() {
  // prefer the linked tab's origin if available
  try {
    if (window.HermesLink && typeof HermesLink.getBaseUrl === 'function') {
      const linkedBase = await HermesLink.getBaseUrl(); // e.g., https://foo.mykronos.com
	  // warn if linked status isn't "ok"
		try {
		  const { hermesLinkedStatus } = await chrome.storage.session.get('hermesLinkedStatus');
		  if (hermesLinkedStatus && hermesLinkedStatus !== 'ok') {
		    appLogger.info('API AccessPanel linked tab status:', hermesLinkedStatus, '(you may need to re-auth or relink).');
		  }
		} catch {}

      if (linkedBase) {
        const validation = validateWebPage(linkedBase);
        if (validation?.valid) {
          const vanityUrl = getVanityUrl(linkedBase);
          return vanityUrl || null;
        } else {
          cappLogger.info(validation?.message || 'Linked base URL failed validation.');
          // fall through to active-tab mode
        }
      }
    }
  } catch (e) {
    // non-fatal: just fall back to active-tab mode
    appLogger.info('HermesLink.getBaseUrl failed; falling back to active tab.', e);
  }

  // 2) fallback: use the active tab
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs && tabs.length > 0) {
        const tabUrl = tabs[0].url;

        const validation = validateWebPage(tabUrl);
        if (!validation.valid) {
          appLogger.info(validation.message);
          resolve(null);
        } else {
          const vanityUrl = getVanityUrl(tabUrl);
          resolve(vanityUrl || null);
        }
      } else {
        appLogger.info('No active tab detected.');
        resolve(null);
      }
    });
  });
}

// Overlay Return To Linked Tab Button
async function handleReturnToLinkedTab(button) {
    if (!button) return;

    try {
        button.disabled = true;
        await HermesLink.goToLinkedTab();
    } catch (error) {
        appLogger.error('Failed to return to linked tab:', error);
        alert('Unable to return to linked tab: ' + error.message);
    } finally {
        button.disabled = false;
    }
}

// Overlay Link This Tab Instead Button
async function handleRelinkToCurrentTab(button) {
    if (!button) return;

    try {
        button.disabled = true;

        // use chrome.tabs API directly instead of private getActiveTab
        const [currentTab] = await chrome.tabs.query({ 
            active: true, 
            currentWindow: true 
        });
        
        if (!currentTab) {
            throw new Error('No active tab found');
        }

        const validation = validateWebPage(currentTab.url);
        if (!validation.valid) {
            throw new Error(validation.message);
        }

        await HermesLink.relinkToCurrentTab(currentTab);
        appLogger.info('Successfully relinked to current tab');
    } catch (error) {
        appLogger.error('Failed to relink to current tab:', error);
        alert('Unable to link this tab: ' + error.message);
    } finally {
        button.disabled = false;
    }
}

// HermesLink: Enhanced Tab Management And Session Tracking
window.HermesLink = (function () {
    const PING_INTERVAL = 60 * 1000; // 1 minute polling
    const SESSION_KEYS = {
        TAB_ID: 'hermesLinkedTabId',
        WINDOW_ID: 'hermesLinkedWindowId',
        URL: 'hermesLinkedUrl',
        ORIGIN: 'hermesLinkedOrigin',
        TITLE: 'hermesLinkedTitle',
        STATUS: 'hermesLinkedStatus',
        LAST_VALIDATION: 'hermesLastValidation',
        VALIDATION_MESSAGE: 'hermesValidationMessage'
    };

    // status messages
    const STATUS_MESSAGES = {
        OK: {
            banner: 'Active Tab: ', 
            hint: 'Session active in this tab',
            overlay: null
        },
        STALE: {
            banner: 'Session Needs Attention: ',
            hint: 'Your session may have expired. Please refresh the page.',
            overlay: 'Session may have expired. Return to WFM to refresh your session.'
        },
        INVALID: {
            banner: 'Invalid Session: ',
            hint: 'Please return to a valid WFM page.',
            overlay: 'Invalid WFM session. Return to a valid WFM page to continue.'
        },
        WRONG_TAB: {
            banner: 'Not Active Tab: ',
            hint: 'Return to linked tab to use Hermes',
            overlay: 'API AccessPanel is active in another tab. Click below to return.'
        }
    };

    // state management
    const state = {
        isInitialized: false,
        checkingState: false
    };

    // helper functions
    const getActiveTab = async () => {
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            return tab || null;
        } catch (e) {
            appLogger.error('Failed to get active tab:', e);
            return null;
        }
    };

    const getLinkedState = async () => {
        try {
            return await chrome.storage.session.get(Object.values(SESSION_KEYS));
        } catch (e) {
            appLogger.error('Failed to get linked state:', e);
            return {};
        }
    };

    const updateLinkedState = async (newState) => {
        try {
            const timestamp = new Date().toISOString();
            await chrome.storage.session.set({
                ...newState,
                hermesLastValidation: timestamp
            });
            appLogger.debug('Updated linked state:', { ...newState, timestamp });
        } catch (e) {
            appLogger.error('Failed to update linked state:', e);
        }
    };


      
    const updateUI = async (validationResult = null) => {
    const { 
        hermesLinkedTabId, 
        hermesLinkedStatus,
        hermesValidationMessage
    } = await getLinkedState();
    
    const currentTab = await getActiveTab();
    const isLinkedTab = currentTab?.id === hermesLinkedTabId;
    
    // determine if current tab is a valid wfm session
    const currentTabValidation = currentTab ? validateWebPage(currentTab.url) : { valid: false };
    
    // determine current status
    let currentStatus = 'OK';
    if (!isLinkedTab) {
        currentStatus = 'WRONG_TAB';
    } else if (hermesLinkedStatus === 'stale') {
        currentStatus = 'STALE';
    } else if (validationResult && !validationResult.valid) {
        currentStatus = 'INVALID';
    }

    const statusConfig = STATUS_MESSAGES[currentStatus];
    
    // update overlay
    const overlay = document.getElementById('hermes-overlay');
    if (overlay) {
        const overlayMessage = document.querySelector('.overlay-content p');
        const relinkButton = document.getElementById('hermes-relink-tab');
        
        if (overlayMessage && statusConfig.overlay) {
            overlayMessage.textContent = statusConfig.overlay;
        }

        // show/hide relink button based on current tab validity
        if (relinkButton) {
            if (currentTabValidation.valid) {
                relinkButton.style.display = 'inline-block';
            } else {
                relinkButton.style.display = 'none';
            }
        }

        overlay.classList.toggle('visible', currentStatus !== 'OK');
    }

        // update banner
        const banner = document.getElementById('hermes-link-banner');
        if (banner) {
            const status = document.getElementById('hermes-link-status');
            const target = document.getElementById('hermes-link-target');
            const hint = document.getElementById('hermes-link-hint');
            
            if (status) status.textContent = statusConfig.banner;
            if (target) target.textContent = currentTab?.title || '';
            if (hint) hint.textContent = hermesValidationMessage || statusConfig.hint;
        }
        
        // update body state - this is critical for the overlay functionality
        document.body.classList.toggle('tab-inactive', currentStatus !== 'OK');

        appLogger.info('UI Updated:', { status: currentStatus, isLinkedTab });
    };

    // session validation
    const validateSession = async () => {
        const { hermesLinkedUrl, hermesLinkedTabId } = await getLinkedState();
        
        if (!hermesLinkedUrl || !hermesLinkedTabId) {
            return { ok: false, code: 'nolink', message: 'No linked session found' };
        }

        try {
            const tab = await chrome.tabs.get(hermesLinkedTabId).catch(() => null);
            if (!tab) {
                await updateLinkedState({ 
                    hermesLinkedStatus: 'stale',
                    hermesValidationMessage: 'Linked tab was closed'
                });
                return { ok: false, code: 'closed', message: 'Linked tab was closed' };
            }

            const validation = validateWebPage(tab.url);
            if (!validation.valid) {
                await updateLinkedState({ 
                    hermesLinkedStatus: 'stale',
                    hermesValidationMessage: validation.message
                });
                return { ok: false, code: 'invalid', validation };
            }

            await updateLinkedState({ 
                hermesLinkedStatus: 'ok',
                hermesValidationMessage: 'Session active'
            });

            return { ok: true, code: 'ok', validation };
        } catch (e) {
            appLogger.error('Session validation failed:', e);
            await updateLinkedState({ 
                hermesLinkedStatus: 'stale',
                hermesValidationMessage: 'Unable to verify session'
            });
            return { ok: false, code: 'error', message: 'Session check failed' };
        }
    };

    // core functionality
    const core = {
        async validateAndUpdateState() {
            if (state.checkingState) return;
            state.checkingState = true;

            try {
                const validationResult = await validateSession();
                await updateUI(validationResult.validation);
                return validationResult;
            } catch (e) {
                appLogger.error('State check failed:', e);
            } finally {
                state.checkingState = false;
            }
        },

		async switchToLinkedTab() {
			try {
				const { hermesLinkedTabId } = await getLinkedState();
				if (!hermesLinkedTabId) {
					throw new Error('No linked tab found');
				}
		
				const tab = await chrome.tabs.get(hermesLinkedTabId).catch(() => null);
				if (!tab) {
					throw new Error('Linked tab no longer exists');
				}
		
				// get current window state
				const currentWindow = await chrome.windows.get(tab.windowId);
				appLogger.debug('Current window state:', currentWindow.state);
		
				// switch to window while preserving its state
				await chrome.windows.update(tab.windowId, {
					focused: true,
					// only pass state if it's not 'normal' to preserve maximized/fullscreen
					...(currentWindow.state !== 'normal' && { state: currentWindow.state })
				});
		
				// small delay before activating tab
				await new Promise(resolve => setTimeout(resolve, 100));
		
				// activate the tab
				await chrome.tabs.update(hermesLinkedTabId, { active: true });
				await new Promise(resolve => setTimeout(resolve, 250));
				await this.validateAndUpdateState();
		
			} catch (error) {
				appLogger.error('Tab switch failed:', error);
				throw error;
			}
		},

        async initialize() {
            if (state.isInitialized) return;
            
            appLogger.info('Initializing HermesLink');

            // initial state check
            await this.validateAndUpdateState();

            // set up periodic check
            setInterval(() => {
                this.validateAndUpdateState().catch(e => 
                    appLogger.error('Periodic check failed:', e)
                );
            }, PING_INTERVAL);

            state.isInitialized = true;
            appLogger.info('HermesLink initialized');
        }
    };

    // initialize core
    core.initialize().catch(e => appLogger.error('Failed to initialize HermesLink:', e));

    // public api
    return {
        checkState: () => core.validateAndUpdateState(),
        goToLinkedTab: () => core.switchToLinkedTab(),
        relinkToCurrentTab: async (tab) => {
            if (!tab?.url) {
                throw new Error('No active tab');
            }

            const validation = validateWebPage(tab.url);
            if (!validation.valid) {
                throw new Error(validation.message);
            }

            await updateLinkedState({
                [SESSION_KEYS.TAB_ID]: tab.id,
                [SESSION_KEYS.WINDOW_ID]: tab.windowId,
                [SESSION_KEYS.URL]: tab.url,
                [SESSION_KEYS.ORIGIN]: new URL(tab.url).origin,
                [SESSION_KEYS.TITLE]: tab.title || '',
                [SESSION_KEYS.STATUS]: 'ok',
                hermesValidationMessage: 'Successfully linked to current tab'
            });

            await core.validateAndUpdateState();
        },
        getBaseUrl: async () => {
            const { hermesLinkedOrigin, hermesLinkedStatus } = await getLinkedState();
            return hermesLinkedStatus === 'ok' ? hermesLinkedOrigin : null;
        }
    };
})();
// ============================= //


// ===== EVENT LISTENERS ===== //
document.addEventListener("DOMContentLoaded", async () => {
	console.log("DOMContentLoaded event fired. Initializing apiaccesspanel extension...");

    const vanityUrl = await getClientUrl();
    if (vanityUrl) {
        console.log("Client URL (vanity):", vanityUrl);
    } else {
        console.log("No valid client URL detected.");
    }

	  await populateClientUrlField();
    await populateClientID();
    await populateAccessToken();
	  await populateClientSecret();
    await populateRefreshToken();
    await restoreTokenTimers();
    await populateThemeDropdown();
    await restoreSelectedTheme();
    buildThemeMenuFromSelect();
    wireThemeMenuClicks();
    initMenus();
    initTitleBarActions();
    await populateApiDropdown();

  // collapsible sections
  document.getElementById("toggle-tenant-section")?.addEventListener("click", toggleTenantSection);
  document.getElementById("toggle-access-section")?.addEventListener("click", toggleAccessSection);
  document.getElementById("toggle-refresh-token-options")?.addEventListener("click", toggleRefreshTokenOptions);
  document.getElementById("toggle-api-library")?.addEventListener("click", toggleApiLibrary);

  // restore persisted states on load
  restoreTenantSection();
  restoreAccessSection();
  restoreRefreshTokenOptions();
  restoreApiLibrary();	

	// admin menu
	document.getElementById("clear-all-data").addEventListener("click", clearAllData);
	document.getElementById("clear-client-data").addEventListener("click", clearClientData);
	document.getElementById("view-client-data").addEventListener("click", viewClientData);
	document.getElementById("export-csv").addEventListener("click", exportCSV);
	document.getElementById("export-json").addEventListener("click", exportJSON);
	document.getElementById("import-data").addEventListener("click", importData);

	// links menu
	document.getElementById("links-boomi").addEventListener("click", linksBoomi);
	document.getElementById("links-install-integrations").addEventListener("click", linksInstallIntegrations);
	document.getElementById("links-developer-portal").addEventListener("click", linksDeveloperPortal);

	// theme menu
	document.getElementById("theme-selector")?.addEventListener("change", themeSelection);
 
	// help menu
	document.getElementById("help-about").addEventListener("click", helpAbout);
	document.getElementById("help-support").addEventListener("click", helpSupport);

  // api access client url
	document.getElementById("refresh-client-url")?.addEventListener("click", refreshClientUrlClick);
	document.getElementById("copy-client-url")?.addEventListener("click", copyClientUrlClick);
	
	// save client id button
	const saveClientIDButton = document.getElementById("save-client-id");
	if (saveClientIDButton) {
		saveClientIDButton.addEventListener("click", saveClientIDClick);
	}
	
	// get access token nutton
	const getTokenButton = document.getElementById("get-token");
	if (getTokenButton) {
		getTokenButton.addEventListener("click", fetchToken);
	}

	// copy access token button
	document.getElementById("copy-token")?.addEventListener("click", copyAccessToken);

	// save client secret button
	const saveClientSecretButton = document.getElementById("save-client-secret");
	if (saveClientSecretButton) {
		saveClientSecretButton.addEventListener("click", saveClientSecretClick);
	}

	// client secret visibility
	document.getElementById("toggle-client-secret").addEventListener("click", toggleClientSecretVisibility);

	// refresh access token button
	const refreshTokenButton = document.getElementById("refresh-access-token");
	if (refreshTokenButton) {
		refreshTokenButton.addEventListener("click", refreshAccessToken);
	}

	// copy refresh token button
	document.getElementById("copy-refresh-token")?.addEventListener("click", copyRefreshToken);

  // mask these fields by default
  ensureMasked("client-url");
  ensureMasked("client-id");
  ensureMasked("access-token");
  ensureMasked("refresh-token");

  // wire their toggles once
  wireRevealToggleOnce("client-url",     "toggle-client-url");
  wireRevealToggleOnce("client-id",      "toggle-client-id");
  wireRevealToggleOnce("access-token",   "toggle-access-token");
  wireRevealToggleOnce("refresh-token",  "toggle-refresh-token");

  // api selector
  const apiSel = document.getElementById("api-selector");
  if (apiSel && !apiSel.dataset.changeListenerAttached) {
    apiSel.addEventListener("change", (e) => {
      void handleApiSelection(e.target.value);
    });
    apiSel.dataset.changeListenerAttached = "1";
  }

  // api buttons
	document.getElementById("execute-api").addEventListener("click", executeApiCall);
	document.getElementById("copy-api-response").addEventListener("click", copyApiResponse);
	document.getElementById("view-request-details").addEventListener("click", showRequestDetails);
  document.getElementById("reset-params")?.addEventListener("click", onResetParamsClick);

	// popout response
	const popoutResponseButton = document.getElementById("popout-response");
	if (popoutResponseButton) {
		popoutResponseButton.addEventListener("click", popoutResponse);
	}

  // save request for my api
  document.getElementById("save-request")?.addEventListener("click", onSaveRequestClick);

  // wire escape my api ui  
  document.addEventListener("keydown", (e) => {
    const overlay = document.getElementById("manage-myapis-overlay");
    if (e.key === "Escape" && overlay && !overlay.hidden) {
      closeMyApisManager();
    }
    });

  // hermeslink button handlers
  const returnButton = document.getElementById('hermes-return-to-tab');
  if (returnButton) {
    returnButton.addEventListener('click', () => handleReturnToLinkedTab(returnButton));
  }

  const relinkButton = document.getElementById('hermes-relink-tab');
  if (relinkButton) {
    relinkButton.addEventListener('click', () => handleRelinkToCurrentTab(relinkButton));
  }

  // visibility change handler
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) {
      HermesLink.checkState().catch(e => appLogger.error('Visibility check failed:', e));
    }
  });

  // focus handler
  window.addEventListener('focus', () => {
    HermesLink.checkState().catch(e => 
      appLogger.error('Focus check failed:', e)
    );
  });
});