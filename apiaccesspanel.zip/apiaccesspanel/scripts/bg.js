// Background Script (bg.js)

// Debug Configuration
const DEBUG_MODE = {
    enabled: false,      // Master switch for logging
    logLevel: 'INFO'     // Default log level (ERROR, WARN, INFO, DEBUG)
};

// Logger utility
const appLogger = {
    timestamp() {
        return new Date().toISOString().slice(0, 19).replace('T', ' ');
    },

    error(message) {
        if (DEBUG_MODE.enabled) {
            console.error(`[${this.timestamp()}][ERROR] ${message}`);
        }
        this.appendToStorage('ERROR', message);
    },

    warn(message) {
        if (DEBUG_MODE.enabled && ['ERROR', 'WARN'].includes(DEBUG_MODE.logLevel)) {
            console.warn(`[${this.timestamp()}][WARN] ${message}`);
        }
        this.appendToStorage('WARN', message);
    },

    info(message) {
        if (DEBUG_MODE.enabled && ['ERROR', 'WARN', 'INFO'].includes(DEBUG_MODE.logLevel)) {
            console.info(`[${this.timestamp()}][INFO] ${message}`);
        }
        this.appendToStorage('INFO', message);
    },

    debug(message) {
        if (DEBUG_MODE.enabled && DEBUG_MODE.logLevel === 'DEBUG') {
            console.debug(`[${this.timestamp()}][DEBUG] ${message}`);
        }
        this.appendToStorage('DEBUG', message);
    },

    async appendToStorage(level, message) {
        try {
            const logEntry = {
                timestamp: this.timestamp(),
                level,
                message
            };
            
            chrome.storage.local.get({ extension_logs: [] }, (result) => {
                const logs = result.extension_logs;
                logs.push(logEntry);
                if (logs.length > 1000) logs.shift();
                chrome.storage.local.set({ extension_logs: logs });
            });
        } catch (error) {
            console.error('Failed to store log:', error);
        }
    }
};

// Global state
let HERMES_GLOBAL_OPEN = false;

// URL validation helpers
const WFM_REGEX = /:\/\/.*\.mykronos\.com\//i;

function isValidWfmSessionUrl(url) {
    if (!url) return false;
    if (!/mykronos\.com/i.test(url)) return false;
    if (/mykronos\.com\/authn\//i.test(url)) return false;
    if (/:\/\/adp-developer\.mykronos\.com\//i.test(url)) return false;
    return true;
}

function isWfmUrl(url) {
    return !!url && WFM_REGEX.test(url);
}

function getOrigin(u) {
    try {
        const url = new URL(u);
        return url.origin;
    } catch {
        return null;
    }
}

// Context management functions
async function setLinkedContext(tab) {
    if (!tab?.id || !isValidWfmSessionUrl(tab.url)) return;

    const payload = {
        hermesLinkedTabId: tab.id,
        hermesLinkedUrl: tab.url,
        hermesLinkedOrigin: getOrigin(tab.url),
        hermesLinkedTitle: tab.title || '',
        hermesLinkedStatus: 'ok'
    };
    await chrome.storage.session.set(payload);
    appLogger.debug('Linked context set:', payload);
}

async function clearLinkedContext(reason = 'closed') {
    const payload = {
        hermesLinkedTabId: null,
        hermesLinkedUrl: null,
        hermesLinkedOrigin: null,
        hermesLinkedTitle: '',
        hermesLinkedStatus: reason
    };
    await chrome.storage.session.set(payload);
    appLogger.debug(`Linked context cleared. Reason: ${reason}`);
}

// Panel management functions
async function setSidePanelEnabledForAll(enabled) {
    try {
        const tabs = await chrome.tabs.query({});
        const ops = tabs.map(t =>
            chrome.sidePanel.setOptions({ 
                tabId: t.id, 
                path: "apiaccesspanel.html", 
                enabled 
            }).catch(() => {})
        );
        await Promise.all(ops);
        appLogger.debug(`Side panel ${enabled ? 'enabled' : 'disabled'} for all tabs`);
    } catch (error) {
        appLogger.error(`Failed to set panel state: ${error}`);
    }
}

// Event handler functions
async function handleStartup() {
    try {
        const { hermesGlobalOpen } = await chrome.storage.session.get('hermesGlobalOpen');
        HERMES_GLOBAL_OPEN = !!hermesGlobalOpen;
        appLogger.info(`Startup state retrieved: ${HERMES_GLOBAL_OPEN}`);
    } catch (error) {
        appLogger.error(`Startup state retrieval failed: ${error}`);
    }
}

async function handleToolbarClick(tab) {
    if (!tab?.id) {
        appLogger.warn('Invalid tab for toolbar click');
        return;
    }

    if (HERMES_GLOBAL_OPEN) {
        appLogger.info('Closing API AccessPanel globally');
        setSidePanelEnabledForAll(false).catch(e => 
            appLogger.error(`Failed to disable panels: ${e}`)
        );
        HERMES_GLOBAL_OPEN = false;
        chrome.storage.session.set({ hermesGlobalOpen: false }).catch(e =>
            appLogger.error(`Failed to update storage: ${e}`)
        );
        return;
    }

    appLogger.info('Opening API AccessPanel');
    
    // Enable panel for current tab
    chrome.sidePanel.setOptions({ 
        tabId: tab.id, 
        path: "apiaccesspanel.html", 
        enabled: true 
    }).catch(e => appLogger.error(`Failed to enable panel: ${e}`));

    // Open the panel
    chrome.sidePanel.open({ tabId: tab.id }).catch(e =>
        appLogger.error(`Failed to open panel: ${e}`)
    );

    // Enable for all tabs
    setSidePanelEnabledForAll(true).catch(e =>
        appLogger.error(`Failed to enable panels globally: ${e}`)
    );

    // Update state
    HERMES_GLOBAL_OPEN = true;
    chrome.storage.session.set({ hermesGlobalOpen: true }).catch(e =>
        appLogger.error(`Failed to update storage: ${e}`)
    );

    // Handle linking
    try {
        if (isValidWfmSessionUrl(tab.url)) {
            await setLinkedContext(tab);
        } else if (/mykronos\.com\/authn\//i.test(tab?.url || '')) {
            await chrome.storage.session.set({ hermesLinkedStatus: 'stale' });
        }
    } catch (error) {
        appLogger.error(`Failed to handle session linking: ${error}`);
    }
}

async function handleTabUpdate(tabId, changeInfo, tab) {
    // Sync panel state
    try {
        const isOpen = apiaccesspanel_GLOBAL_OPEN;
        await chrome.sidePanel.setOptions({ 
            tabId, 
            path: "hermes.html", 
            enabled: isOpen 
        });
    } catch (error) {
        appLogger.error(`Failed to update panel state: ${error}`);
    }

    // Handle linked tab updates
    try {
        const { hermesLinkedTabId } = await chrome.storage.session.get('hermesLinkedTabId');
        if (!hermesLinkedTabId || tabId !== hermesLinkedTabId) return;

        if (changeInfo.url) {
            if (isValidWfmSessionUrl(changeInfo.url)) {
                await setLinkedContext({ 
                    id: tabId, 
                    url: changeInfo.url, 
                    title: tab?.title 
                });
            } else {
                await chrome.storage.session.set({ 
                    hermesLinkedStatus: 'stale', 
                    hermesLinkedUrl: changeInfo.url || null 
                });
            }
        }
        if (changeInfo.title) {
            await chrome.storage.session.set({ hermesLinkedTitle: changeInfo.title });
        }
    } catch (error) {
        appLogger.error(`Failed to handle tab update: ${error}`);
    }
}

async function handleTabRemoved(tabId) {
    try {
        const { hermesLinkedTabId } = await chrome.storage.session.get('hermesLinkedTabId');
        if (hermesLinkedTabId && tabId === hermesLinkedTabId) {
            appLogger.info(`Linked tab closed: ${tabId}`);
            await clearLinkedContext('closed');
        }
    } catch (error) {
        appLogger.error(`Failed to handle tab removal: ${error}`);
    }
}

// Event Listeners
chrome.runtime.onStartup?.addListener(handleStartup);
chrome.action.onClicked.addListener(handleToolbarClick);
chrome.tabs.onUpdated.addListener(handleTabUpdate);
chrome.tabs.onRemoved.addListener(handleTabRemoved);